#!/bin/bash
#Total NGVS monthly report.
#By:Shreef Khattab.
#Enhanced By Mohamed Gamal
#VODAFONE EGYPT 2019 -- CHARGING TEAM  
#ALL RIGHTS RESERVED 
#1. Loaded is the cards that have been loaded during the month Unavailabe -->  available  (available+used)
#2. Available is the cards loaded during the month + the cards loaded before and still available + the cards state changed to (avaialable) during the report taken . 
#3. Used is the cards used during the month  
#4. Dameged is the cards damaged during the month 
#5. Pending is the cards that still pending during the month 
#6. Expired is the cards expired during the month 

#===================================================================
cd /var/opt/vs/main/reports/done

# date of closed month
report_month=`date -d "-10 day" +%Y%m`

# :=report_month - 1
report_lst_month=`date -d "-40 day" +%Y%m`
output_lst_d=${report_lst_month}_dump_output

# :=report_month + 1
report_nxt_month=`date +%Y%m`

formated_dump=`date +%Y%m`01_Total_VSdump.csv
TTdump=`date +%m_01_%Y`

output_d=${report_month}_dump_output
raw_d=dump_`date +%Y%m`01
mkdir ${output_d} 2>/dev/null
#====================================================================
send_sms()
{
for c in `grep -v ^# .smsContacts|awk -F: '{print $2}'`
do
echo "$c;$2"            >> "$1".sms
done
/housekeeping/NewNemo/ftp/ftp_Nemo_New.sh . /housekeeping/SMS_sender/ "$1".sms
rm "$1".sms
return 0
}
#======================================
echo "[`date +%Y%m%d" "%H:%M`] 1/23. Generating formated one file dump file."

:> ${output_d}/${formated_dump}

for i in `ls VOUCHER_DUMP_REPORT_${TTdump}*.csv`
do
gawk -F, '{if($1==5&&!$2&&$NF~/C/){print $7","$3","$4","$13}}' ${i}|sed 's/^\(....\)\(..\)\(..T.............\)/\2-\1/' >> ${output_d}/NewVSCARDS_UnAvail_${report_month}
gawk -F, 'BEGIN{oa=0;na=0}{
if(($NF~/C$/||$NF~/H$/)&&!($1==6&&$NF~/H/)){
if($NF~/H/){
st=$1;sst=$2;C=$3;V=$4;CD=$7;ED=$8;TD=$9;S=$13;M=$14;
line=st","sst","C","V","CD","ED","TD","S","M;
if(st==0&&TD!~/'${report_month}'..T/){oa=1}
if(st==5&&!sst&&TD!~/'${report_month}'..T/){oa=0}
if(st==0&&TD~/'${report_month}'..T/){na=1}
if(st==5&&!sst&&TD~/'${report_month}'..T/){na=0}
}else{if(!(st==5&&!sst&&oa==0)){if(line){print line","oa","na}};oa=0;na=0;line=null}
}}END{if(!(st==5&&!sst)){if(line){print line","oa","na};oa=3;na=3;line=null}}' ${i}|sed 's/T..:..:..+0200,/,/g' >> ${output_d}/${formated_dump}
mv ${i} ${output_d}/
gzip ${output_d}/${i} &
done

#deactivtion
echo "[`date +%Y%m%d" "%H:%M`] 2/23. Generating \"Deactivtion\" report files (1/2)"
gawk -F, '{if($1==5&&!$2&&$(NF-1)==1&&$NF==0){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_deactivation_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 3/23. Generating \"Deactivtion\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_deactivation_detailed.csv|sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_deactivation_grouped.csv

#available
echo "[`date +%Y%m%d" "%H:%M`] 4/23. Generating \"Available\" report files (1/2)"
gawk -F, '{if(($1==0&&!$2&&$6!~/'${report_month}'../&&$6!~/'${report_lst_month}'../)||($1==1&&!$2&&$7~/'${report_nxt_month}'../)){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_available_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 5/23. Generating \"Available\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_available_detailed.csv |sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_available_grouped.csv

#pending
echo "[`date +%Y%m%d" "%H:%M`] 6/23. Generating \"Pending\" report files (1/2)"
gawk -F, '{if($1==4&&!$2&&$7~/'${report_month}'../){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_pending_detailed.csv 
echo "[`date +%Y%m%d" "%H:%M`] 7/23. Generating \"Pending\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_pending_detailed.csv|sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_pending_grouped.csv

#used
echo "[`date +%Y%m%d" "%H:%M`] 8/23. Generating \"Used\" report files (1/2)"
gawk -F, '{if($1==1&&!$2&&$7~/'${report_month}'/){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_used_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 9/23. Generating \"Used\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_used_detailed.csv |sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_used_grouped.csv

#damaged
echo "[`date +%Y%m%d" "%H:%M`] 10/23. Generating \"Damaged\" report files (1/2)"
gawk -F, '{if($1==5&&$2~/DAMAGED/&&$7~/'${report_month}'/){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_damaged_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 11/23. Generating \"Damaged\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_damaged_detailed.csv|sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_damaged_grouped.csv

### STOLEN 
echo "[`date +%Y%m%d" "%H:%M`] 12/23. Generating \"Stolen\" report files (1/2)"
gawk -F, '{if($1==5&&$2~/STOLEN/&&$7~/'${report_month}'/){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_stolen_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 13/23. Generating \"Stolen\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_stolen_detailed.csv|sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_stolen_grouped.csv

#loaded
echo "[`date +%Y%m%d" "%H:%M`] 14/23. Generating \"Loaded\" report files (1/2)"
gawk -F, '{if($(NF-1)==0&&$NF==1){print $3","$4","$7","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_loaded_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 15/23. Generating \"Loaded\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_loaded_detailed.csv|sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_loaded_grouped.csv

#expired
echo "[`date +%Y%m%d" "%H:%M`] 16/23. Generating \"Expired\" report files (1/2)"
gawk -F, '{if($1!=1&&!$2&&$6~/'${report_month}'../){print $3","$4","$6","$8}}' ${output_d}/${formated_dump}|uniq > ${output_d}/${report_month}_expired_detailed.csv
echo "[`date +%Y%m%d" "%H:%M`] 17/23. Generating \"Expired\" report files (2/2)"
gawk -F, '{print $1","$2}' ${output_d}/${report_month}_expired_detailed.csv|sort -n|uniq -c|gawk '{print $2","$1}'|gawk -F, 'BEGIN{s=0}{v=$2*$3/100;c+=$3;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}' > ${output_d}/${report_month}_expired_grouped.csv


##--------DWH Files ---------------------------
echo "[`date +%Y%m%d" "%H:%M`] 18/23. Generating \"DWH\" report files (1/4)"
gawk -F, '{print $3","$1","$2","$4}' ${output_d}/${report_month}_available_detailed.csv|sed 's/^\(....\)\(..\)\(..\),/\2-\1,/' > ${output_d}/NewVSCARDS_Avail_${report_month}
gzip  ${output_d}/NewVSCARDS_Avail_${report_month} 
echo "[`date +%Y%m%d" "%H:%M`] 19/23. Generating \"DWH\" report files (2/4)"
gawk -F, '{print $3","$1","$2","$4}' ${output_d}/${report_month}_damaged_detailed.csv|sed 's/^\(....\)\(..\)\(..\),/\2-\1,/'  > ${output_d}/NewVSCARDS_Damaged_${report_month}
gzip ${output_d}/NewVSCARDS_Damaged_${report_month} 
echo "[`date +%Y%m%d" "%H:%M`] 20/23. Generating \"DWH\" report files (3/4)"
gawk -F, '{print $3","$1","$2","$4}' ${output_d}/${report_month}_expired_detailed.csv|sed 's/^\(....\)\(..\)\(..\),/\2-\1,/'  > ${output_d}/NewVSCARDS_Expired_${report_month}
gzip ${output_d}/NewVSCARDS_Expired_${report_month} 
echo "[`date +%Y%m%d" "%H:%M`] 21/23. Generating \"DWH\" report files (4/4)"
gzip ${output_d}/NewVSCARDS_UnAvail_${report_month} 

echo "[`date +%Y%m%d" "%H:%M`] 22/23. sftp to datastage machine."
scp ${output_d}/NewVSCARDS_* ch_user@10.230.91.220:/DS/DataFiles/Enterprise/Prepaid/Vouchers/MonthlyReports/

#---EXTRA TABs , Finance Files ---------------
echo "[`date +%Y%m%d" "%H:%M`]  Generating \"Available VCards with Expiry Dates\" Extra Tab"
gawk -F, '{print $3","$1","$2}' ${output_d}/${report_month}_available_detailed.csv|sed 's/^\(....\)\(..\)\(..\),/\2-\1,/'|sort -n|uniq -c|gawk '{print $1","$2}'|gawk -F, 'BEGIN{s=0}{v=$1*$4/100;c+=$4;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}'> ${output_d}/${report_month}_AvailExpiryDates.csv 

echo "[`date +%Y%m%d" "%H:%M`]  Generating \"Expiry VCards with Unavailable Dates\" Extra Tab"
gawk -F, '{if($1!=1&&!$2&&$6~/'${report_month}'../){print $3","$4","$5","$8}}'  ${output_d}/${formated_dump} |uniq > .tmp 
gawk -F, '{print $3","$1","$2}' .tmp |sed 's/^\(....\)\(..\)\(..\),/\2-\1,/'|sort -n|uniq -c|gawk '{print $1","$2}'|gawk -F, 'BEGIN{s=0}{v=$1*$4/100;c+=$4;s+=v;print $0","v}END{printf(",,,,\nTOTAL,%d,%d,%.2f\n",NR,c,s)}'> ${output_d}/${report_month}_ExpiryUnavaiDates.csv
echo "[`date +%Y%m%d" "%H:%M`] Reports generation is done."
##----------------------------------------------
## Variance
echo "[`date +%Y%m%d" "%H:%M`]  Calculating  \"Variance\" "
LOADED=`grep -i TOTAL ${output_d}/${report_month}_loaded_grouped.csv|gawk -F, '{print $4}'`
OLD_AVAIL=`grep -i TOTAL ${output_lst_d}/${report_lst_month}_available_grouped.csv|gawk -F, '{print $4}'`
SUM=`echo $LOADED + $OLD_AVAIL | bc`
VAR=`grep -i TOTAL ${output_d}/${report_month}_*_grouped.csv|grep -iv loaded |gawk -v sm=${SUM} -F, 'BEGIN{S=sm}{V=$4;S-=V}END{printf("%.0f\n", S)}'`

echo "[`date +%Y%m%d" "%H:%M`] Variance for current month is $VAR"
send_sms NGVS "VS Report variance for `date +%b-%Y` closure is "$VAR" L.E. "
##----------------------------------------------
