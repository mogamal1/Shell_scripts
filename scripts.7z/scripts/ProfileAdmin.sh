#!/bin/bash


#read -p " Please Enter AF IP:  " AFUser
#read -p " Please Enter AF User:  " AFUser
#read -p " Please Enter AF Password:  " AFPass

#read -p " Please Enter Air IP:  " AirFUser
#read -p " Please Enter Air User:  " AirUser
#read -p " Please Enter Air Password:  " AirPass

AirUser=uciptool
AirPass=uciptool_123
AirIP=10.28.21.5

AFUser=uciptool
AFPass=uciptool_123
AFIP=172.30.201.25

AF33_User=uciptool
AF33_Pass=uciptool_123
AF33_IP=10.28.21.5


home=/export/home/fdsuser/AIR_UCIP
wd=/export/home/fdsuser/AIR_UCIP/Working
tmpDir=/export/home/fdsuser/AIR_UCIP/Working/tmp$$
oDir=/export/home/fdsuser/AIR_UCIP/OUTPUT
UCIP=/export/home/fdsuser/AIR_UCIP/UCIP
WLIST=$tmpDir/LIST.working
mkdir -p $tmpDir 2>/dev/null
mkdir -p $oDir 2>/dev/null
LogFile=ProfileAdmin_`date +%Y%m%d`.log

TRANSACTIONDATE=`date +%Y%m%dT%H:%M:00`
DATE=`date +%Y%m%d`
YEAR=`date +%Y`

if [ $# -eq 0 ] ; then
SKIP=NO
HELP=YES

elif [ $# -eq 2 ] ; then
SKIP=YES
HELP=NO
ACTION=`echo $1  | tr "[:lower:]" "[:upper:]"`
INPUT=`echo $2`
INPUTCOUNT=`echo $INPUT | grep [A-z] | egrep -iv "ADD|DELETE|SDP" | wc -l`
if [[ -z $INPUTCOUNT ]] ; then INPUTCOUNT=00000 ; fi

if  [ $INPUTCOUNT -gt 0 ] ; then 
cat $INPUT  | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > "$WLIST" 
INPUT=BATCH
else echo $INPUT |  tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > "$WLIST"
fi


elif [ $# -eq 3 ] ; then
SKIP=YES
HELP=NO

ACTION=`echo $1  | tr "[:lower:]" "[:upper:]"`
TYPE=`echo $2  | tr "[:lower:]" "[:upper:]"`
INPUT=`echo $3`
INPUTCOUNT=`echo $INPUT | awk -F, '{print $1 }' | grep [A-z] | egrep -iv "ADD|DEL" | wc -l`

if [[ -z $INPUTCOUNT ]] ; then INPUTCOUNT=00000 ; fi
if  [ $INPUTCOUNT -gt 0 ] ; then  
cat $INPUT  | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > "$WLIST" 
INPUT=BATCH
else echo $INPUT | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'  > "$WLIST" 
fi

else
SKIP=YES
HELP=YES
ACTION=HELP
fi


#################################################
#           Checking Air Connectivity           #
#################################################


cat << EOF > $tmpDir/CkAir.sh
#!/usr/bin/expect
set timeout 5

spawn ssh $AirUser@$AirIP
    expect "ssword: "
    send "$AirPass\r"
    expect "$ "
    send "id\r"
    expect "$ "
    send "exit\r"
EOF
chmod 777 $tmpDir/CkAir.sh
$tmpDir/CkAir.sh > $tmpDir/CkAir.out
id=`cat  $tmpDir/CkAir.out | grep uid | awk -F'(' '{print $2}'  | awk -F')' '{print $1}'`

if [[ -z $id ]] ; then id=00000 ; fi
if [ `echo $id` == `echo $AirUser` ] ; then echo " \n=====================================================\n \n Connected to AIR: $AirIP User: $AirUser \n \n Start: `date` \n " >> $oDir/$LogFile ; else echo ' Incorrect AIR username or pasword!  Script will  STOP! ' >> $oDir/$LogFile ; echo " " ; exit -3 ; fi
#################################################

log ( )
{
echo $*
echo $* >>$oDir/$LogFile
}


DateCalaulator ( )
{
INPUT=$1 

cat << EOF > $tmpDir/DATE.pl

#!/usr/bin/perl

use strict;
use Time::localtime;
use Time::Local;

my \$tm = localtime;

my \$TIME = timelocal(\$tm->sec, \$tm->min, \$tm->hour, \$tm->mday, \$tm->mon, \$tm->year+1900);
\$TIME = \$TIME + `echo $INPUT` * 24 * 60 * 60;

\$tm = localtime(\$TIME);
printf("Output Date New: %04d%02d%02d\n",
                  \$tm->year+1900,\$tm->mon+1, \$tm->mday

                  );
EOF
perl $tmpDir/DATE.pl 
}


afwhere ( ) 
{
MSISDN=$1
cat << EOF > $tmpDir/SDP.sh
#!/usr/bin/expect
set timeout 5

spawn ssh $AF33_User@$AF33_IP
    expect "word: "
    send "$AF33_Pass\r"
    expect "$ "
    send "afwhere `echo $MSISDN`\r"
    expect "$ "
    send "afwhere `echo $MSISDN | cut -c 1-7`\r"
    expect "$ "
    send "exit\r"
EOF
chmod 777 $tmpDir/SDP.sh
$tmpDir/SDP.sh > $tmpDir/SDP.out
dos2unix $tmpDir/SDP.out | grep $MSISDN | grep -i SDP | awk '{print $2}' | sed 's/ //g' > $tmpDir/SDP.current
dos2unix $tmpDir/SDP.out | grep `echo $MSISDN | cut -c 1-7`" " | grep -i SDP | awk '{print $2}' | sed 's/ //g' > $tmpDir/SDP.default
}


afchange ( ) 
{
cat << EOF > $tmpDir/ChangeSDP.sh
#!/usr/bin/expect
set timeout 5

spawn telnet $AFIP
    expect "login: "
    send "$AFUser\r"
    expect "Password: "
    send "$AFPass\r"
    expect "$ "
    send "afchange $MSISDN $SDP\r"
    expect "$ "
    send "sleep 1\r"
    expect "$ "
    send "afwhere `echo $MSISDN | cut -c 1-7`\r"
    expect "$ "
    send "afwhere $MSISDN\r"
    expect "$ "
    send "exit\r"
EOF
chmod 777 $tmpDir/ChangeSDP.sh
$tmpDir/ChangeSDP.sh > $tmpDir/ChangeSDP.out

cat << EOF > $tmpDir/ChangeSDP_AF33.sh
#!/usr/bin/expect
set timeout 5

spawn ssh $AF33_User@$AF33_IP
    expect "word: "
    send "$AF33_Pass\r"
    expect "$ "
    send "afchange $MSISDN $SDP\r"
    expect "$ "
    send "sleep 1\r"
    expect "$ "
    send "afwhere `echo $MSISDN | cut -c 1-7`\r"
    expect "$ "
    send "afwhere $MSISDN\r"
    expect "$ "
    send "exit\r"
EOF

chmod 777 $tmpDir/ChangeSDP_AF33.sh
$tmpDir/ChangeSDP_AF33.sh > $tmpDir/ChangeSDP_AF33.out

dos2unix $tmpDir/ChangeSDP.out | tail -4 | grep $MSISDN | grep -i SDP | awk '{print $2}' | sed 's/ //g' > $tmpDir/SDP.current
dos2unix $tmpDir/ChangeSDP.out | tail -4 | grep `echo $MSISDN | cut -c 1-7`" " | grep -i SDP | awk '{print $2}' | sed 's/ //g' > $tmpDir/SDP.default
}

#################################################
##           Input  Lists   Validation          #
#################################################

V_NFCount ( ) 
{ 
V_NFCount=`cat $WLIST | awk -F, '{print NF}' | sort | uniq | wc -l` 
}

V_NF ( )
{ 
V_NF=`cat $WLIST | awk -F, '{print NF}' | sort | uniq | head -1` 
}

V_FLCount ( ) 
{ 
V_FLCount=`cat $WLIST | awk '{print length($0); }' | sort | uniq | wc -l` 
}

V_FL ( )
{ 
V_FL=`cat $WLIST | awk '{print length($0); }' | sort | uniq | head -1` 
}

V_FLCount1 ( ) 
{ 
V_FLCount1=`cat $WLIST | awk -F, '{print length($1); }' | sort | uniq | wc -l` 
}

V_FL1 ( )
{ 
V_FL1=`cat $WLIST | awk -F, '{print length($1); }' | sort | uniq | head -1` 
}

V_FLCount2 ( ) 
{ 
V_FLCount2=`cat $WLIST | awk -F, '{print length($2); }' | sort | uniq | wc -l` 
}

V_FL2 ( )
{ V_FL2=`cat $WLIST | awk -F, '{print length($2); }' | sort | uniq | head -1` 
}

V_FLCount3 ( ) 
{ V_FLCount3=`cat $WLIST | awk -F, '{print length($3); }' | sort | uniq | wc -l` 
}

V_FL3 ( )
{ V_FL3=`cat $WLIST | awk -F, '{print length($3); }' | sort | uniq | head -1` 
}

V_FLCount4 ( ) 
{ 
V_FLCount4=`cat $WLIST | awk -F, '{print length($4); }' | sort | uniq | wc -l` 
}

V_FL4 ( )
{ 
V_FL4=`cat $WLIST | awk -F, '{print length($4); }' | sort | uniq | head -1` 
}

V_FLCount5 ( ) 
{ 
V_FLCount5=`cat $WLIST | awk -F, '{print length($5); }' | sort | uniq | wc -l` 
}

V_FL5 ( )
{ 
V_FL5=`cat $WLIST | awk -F, '{print length($5); }' | sort | uniq | head -1` 
}

V_FLCount6 ( ) 
{ 
V_FLCount6=`cat $WLIST | awk -F, '{print length($6); }' | sort | uniq | wc -l` 
}
V_FL6 ( )
{ 
V_FL6=`cat $WLIST | awk -F, '{print length($6); }' | sort | uniq | head -1` 
}

V_NUMF ( )
{ 
V_NUMF=`cat $WLIST | awk '{print $0}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_NUMF1 ( )
{ 
V_NUMF1=`cat $WLIST | awk -F, '{print $1}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_NUMF2 ( )
{ 
V_NUMF2=`cat $WLIST | awk -F, '{print $2}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_NUMF3 ( )
{ 
V_NUMF3=`cat $WLIST | awk -F, '{print $3}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_NUMF4 ( )
{ 
V_NUMF4=`cat $WLIST | awk -F, '{print $4}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_NUMF5 ( )
{ 
V_NUMF5=`cat $WLIST | awk -F, '{print $5}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_NUMF6 ( )
{ 
V_NUMF6=`cat $WLIST | awk -F, '{print $6}' | egrep "[A-z]|;|,|\*" | wc -l` 
}

V_ADDDEL ( )
{ 
V_ADDDEL=`cat $WLIST | awk -F, '{print $2}' | egrep -v "ADD|DELETE" | wc -l` 
}

V_SDP ( )
{
V_SDP=`cat $WLIST | awk -F, '{print $2}' | egrep -v "^SDP[0-9][0-9]$" | wc -l`
}

V_NULL ( )
{
V_NULL=`cat $WLIST | awk -F, '{print $2}' | egrep -v "SDP|DEFAULT|NULL|BLANK" | wc -l`
}
#################################################
if [ $SKIP == 'NO' ] ; then
#################################################
 
# clear the screen
tput clear
 
# Move cursor to screen location X,Y (top left is 0,0)
tput cup 3 15
 
# Set a foreground colour using ANSI escape
tput setaf 3
echo "Vodafone Egypt"
tput sgr0
 
tput cup 5 17
# Set reverse video mode
tput rev
echo " M A I N - M E N U "
tput sgr0
 
tput cup 7 15
echo "1. Get Profile"
 
tput cup 8 15
echo "2. Set Profile"
echo " "
echo " " 

tput cup 9 15
echo "3. Migrate Profile"
echo " "
echo " "

tput cup 10 15
echo "4. Force Migrate Profile"
echo " "
echo " "

tput cup 11 15
echo "5. Batches HELP"
echo " "
echo " "
read -p "Enter your choice [1-5] " choice
 
tput clear
tput sgr0
tput rc
clear


if [ -z $choice ] ; then log ' Invalid Choice!  Script will  STOP! ' ; log ' ' ; exit -3 
elif [ $choice == "1" ] ; then ACTION=GET 
elif [ $choice == "2" ] ; then ACTION=SET
elif [ $choice == "3" ] ; then ACTION=MIGRATE
elif [ $choice == "4" ] ; then ACTION=FORCEMIGRATE
elif [ $choice == "5" ] ; then ACTION=HELP
else
log ' ' ; log ' Invalid Choice!  Script will  STOP! ' ; log ' ' ; exit -3
fi

###############################################################################################################################################################################################

if [ $ACTION == "GET" ] ; then

# clear the screen
tput clear

# Move cursor to screen location X,Y (top left is 0,0)
tput cup 3 15

# Set a foreground colour using ANSI escape
tput setaf 3
echo "Vodafone Egypt"
tput sgr0

tput cup 5 17
# Set reverse video mode
tput rev
echo " $ACTION - M E N U "
tput sgr0

tput cup 7 15
echo "1. SDP on Account Finder"

tput cup 8 15
echo "2. Service Class"

tput cup 9 15
echo "3. Main Balance"

tput cup 10 15
echo "4. Dedicated Account"

tput cup 11 15
echo "5. Dates"

tput cup 12 15
echo "6. Community"

tput cup 13 15
echo "7. Service Offering Bits"

tput cup 14 15
echo "8. Accumulators"

tput cup 15 15
echo "9. AccountGroup"

tput cup 16 15
echo "10. Language"

tput cup 17 15
echo "11. Family And Friends"

tput cup 18 15
echo "12. Offers"

tput cup 19 15
echo "13. Usage Counters"

tput cup 20 15
echo "14. Usage Thresholds"

tput cup 21 15
echo "15. Periodic Account Management"
echo " "

read -p "Enter your choice [1-15] " choice

tput clear
tput sgr0
tput rc
clear

if [ -z $choice ] ; then log ' Invalid Choice!  Script will  STOP! ' ; log ' ' ; exit -3
elif [ $choice == "1" ] ; then TYPE=AF
elif [ $choice == "2" ] ; then TYPE=SC
elif [ $choice == "3" ] ; then TYPE=MB
elif [ $choice == "4" ] ; then TYPE=DA
elif [ $choice == "5" ] ; then TYPE=DATES
elif [ $choice == "6" ] ; then TYPE=COM
elif [ $choice == "7" ] ; then TYPE=SOB
elif [ $choice == "8" ] ; then TYPE=ACC
elif [ $choice == "9" ] ; then TYPE=AG
elif [ $choice == "10" ] ; then TYPE=LANG
elif [ $choice == "11" ] ; then TYPE=FAF
elif [ $choice == "12" ] ; then TYPE=OFFER
elif [ $choice == "13" ] ; then TYPE=UC
elif [ $choice == "14" ] ; then TYPE=UT
elif [ $choice == "15" ] ; then TYPE=PAM
else
log ' ' ; log ' Invalid Choice!  Script will  STOP! ' ; log ' ' ; exit -3
fi


read -p " Please Enter MSISDN in ANY Format or Type BATCH: " InputTmp
INPUT=`echo $InputTmp  | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'`
if [[ -z $INPUT ]] ; then log ' Invalid Input! Script will  STOP! ' ; exit -3 ; fi

VALIDATE=`echo $INPUT | grep [0-9] | egrep -v "[A-z]|;|,|\*" | wc -m`


if [ $INPUT == "BATCH" ] ; then VALIDATE=11 ; fi
if [ $INPUT != "BATCH" ]|[ $VALIDATE -ne "11" ] ; then log ' ' ; log ' Invalid Input!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ $INPUT != "BATCH" ] ; then echo $INPUT > $WLIST ; if [ `cat $WLIST | grep [0-9] | wc -l` -lt 1 ] ; then  log ' Invalid MSISDN!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi ; fi
log ' '

###############################################################################################################################################################################################

elif [ $ACTION == "SET" ] ; then

# clear the screen
tput clear

# Move cursor to screen location X,Y (top left is 0,0)
tput cup 3 15

# Set a foreground colour using ANSI escape
tput setaf 3
echo "Vodafone Egypt"
tput sgr0

tput cup 5 17
# Set reverse video mode
tput rev
echo " $ACTION - M E N U "
tput sgr0

tput cup 7 15
echo "1. SDP on Account Finder"

tput cup 8 15
echo "2. Install MSISDN"

tput cup 9 15
echo "3. Delete MSISDN"

tput cup 10 15
echo "4. Delete Wrong SDP"

tput cup 11 15
echo "5. Service Class"

tput cup 12 15
echo "6. Main Balance"

tput cup 13 15
echo "7. Dedicated Account"

tput cup 14 15
echo "8. Dates"

tput cup 15 15
echo "9. Community"

tput cup 16 15
echo "10. Service Offering Bits"

tput cup 17 15
echo "11. Accumulators"

tput cup 18 15
echo "12. AccountGroup"

tput cup 19 15
echo "13. Language"

tput cup 20 15
echo "14. Family And Friends"

tput cup 21 15
echo "15. Offers"

tput cup 22 15
echo "16. Usage Counters"

tput cup 23 15
echo "17. Usage Thresholds"

tput cup 24 15
echo "18. Periodic Account Management"
echo " "
echo " "
read -p "Enter your choice [1-18] " choice

tput clear
tput sgr0
tput rc
clear

if [ -z $choice ] ; then log ' Invalid Choice!  Script will  STOP! ' ; log ' ' ; exit -3
elif [ $choice == "1" ] ; then TYPE=AF
elif [ $choice == "2" ] ; then TYPE=INSTALL
elif [ $choice == "3" ] ; then TYPE=DEL
elif [ $choice == "4" ] ; then TYPE=WRONGSDP
elif [ $choice == "5" ] ; then TYPE=SC
elif [ $choice == "6" ] ; then TYPE=MB
elif [ $choice == "7" ] ; then TYPE=DA
elif [ $choice == "8" ] ; then TYPE=DATES
elif [ $choice == "9" ] ; then TYPE=COM
elif [ $choice == "10" ] ; then TYPE=SOB
elif [ $choice == "11" ] ; then TYPE=ACC
elif [ $choice == "12" ] ; then TYPE=AG
elif [ $choice == "13" ] ; then TYPE=LANG
elif [ $choice == "14" ] ; then TYPE=FAF
elif [ $choice == "15" ] ; then TYPE=OFFER
elif [ $choice == "16" ] ; then TYPE=UC
elif [ $choice == "17" ] ; then TYPE=UT
elif [ $choice == "18" ] ; then TYPE=PAM
else
log ' ' ; log ' Invalid Choice!  Script will  STOP! ' ; log ' ' ; exit -3
fi


read -p " Please Enter MSISDN in ANY Format or Type BATCH: " InputTmp
INPUT=`echo $InputTmp  | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'`
if [[ -z $INPUT ]] ; then log ' Invalid Input! Script will  STOP! ' ; exit -3 ; fi

VALIDATE=`echo $INPUT | grep [0-9] | egrep -v "[A-z]|;|,|\*" | wc -m`

if [ $INPUT == "BATCH" ] ; then VALIDATE=11 ; fi
if [ $INPUT != "BATCH" ]|[ $VALIDATE -ne "11" ] ; then log ' ' ; log ' Invalid Input!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ $INPUT != "BATCH" ] ; then echo $INPUT > $WLIST ; if [ `cat $WLIST | grep [0-9] | wc -l` -lt 1 ] ; then  log ' Invalid MSISDN!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi ; fi
log ' '

fi

###############################################################################################################################################################################################

#################################################
#               MSISDN Migration                #
#################################################

if [ $ACTION == "MIGRATE" ] ; then 

read -p " Please Enter MSISDN in ANY Format or Type BATCH: " InputTmp
INPUT=`echo $InputTmp  | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'`
if [[ -z $INPUT ]] ; then log ' Invalid Input!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
echo " "

if [ $INPUT != "BATCH" ] ; then echo $INPUT > $WLIST ; fi 

if [ $INPUT == "BATCH" ]  ; then  read -p " Please Enter MSISDN List full Path: " LIST 
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST 
fi

## Validate LIST ##

V_FLCount
V_FL
V_NUMF

if [ "$V_FLCount" -ne 1 ]||[ "$V_FL" -ne 10 ]||[ "$V_NUMF" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

## Start Migration ##

for i in `cat $WLIST` ; do
log " $i  Migration Started.. "
log ' ' 
$home/migrate.sh $i $AFIP $AFUser $AFPass $AirIP $AirUser $AirPass $tmpDir
done
fi

#################################################
#            MSISDN Force Migration             #
#################################################

if [ $ACTION == "FORCEMIGRATE" ] ; then

read -p " Please Enter MSISDN in ANY Format or Type BATCH: " InputTmp
read -p " Please Enter Destination SDP (SDPXX): " SDPNewTmp
SDPNew=`echo $SDPNewTmp | tr "[:lower:]" "[:upper:]"` 
if [[ -z $SDPNew ]] ; then log ' Invalid Input!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

INPUT=`echo $InputTmp  | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'`
if [[ -z $INPUT ]] ; then log ' Invalid Input!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
echo " "

if [ $INPUT != "BATCH" ] ; then echo "$INPUT","$SDPNew" > $WLIST ; fi

if [ $INPUT == "BATCH" ]  ; then  read -p " Please Enter MSISDN List full Path (MSISDN in ANY Format,SDPXX): " LIST
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_FLCount
V_FL1
V_NFCount

if [ "$V_FLCount" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NFCount" -ne 1 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi


## Start Migration ##

for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`

log " $MSISDN  $SDP  Migration Started.. "
log ' '

$home/migrate.sh $MSISDN $AFIP $AFUser $AFPass $AirIP $AirUser $AirPass $SDP $tmpDir
done
fi
###############################################################################################################################################################################################

fi ## SKIP=NO

if [ $HELP == 'YES' ] ; then
if [ $SKIP == 'YES' ] ; then clear ; echo " " ; echo " Invalid Input!" ; echo " " ; echo " " ; sleep 2 ; fi
#################################################
#               HELP Menu                       #
#################################################
if [ $ACTION == "HELP" ] ; then
normal=$(tput sgr0)
bold=$(tput bold)
clear
echo "#################################################"
echo "#               HELP Menu                       #"
echo "#################################################"
echo " "
echo " "
echo " This will give you some tips and trics for running BATCHES. "
echo " "
echo " "
sleep 2
echo " You can run $0 with some input paramters. "
echo " "
echo " "
echo " The next examples will show you how to use. "
echo " "
sleep 4
clear
echo "#################################################"
echo "#               HELP Menu                       #"
echo "#################################################"
echo " "
echo " "
sleep 1
printf "$0  "
sleep 1
printf "ACTION:(GET|SET|MIGRATE|FORCEMIGRATE)  "
sleep 1
printf "TYPE:(AF|SC|MB|DA|DATES|COM|SOB|ACC|AG|LANG|FAF|OFFER|UC|UT|PAM)  " 
sleep 1
printf "INPUT:(MSISDN,PARAMETERS|BATCH Full Path)" 
echo " "
echo " "
sleep 2
echo " Do NOT Enter TYPE for MIGRATION "
echo " "
echo " "
echo "   Examples:"
echo " "
echo "                  $0 GET AF 10123456789"
echo "                  $0 GET SC /export/home/fdsuser/SeviceClass.list"
echo " "
echo "                  $0 SET AF 10123456789,SDP55                        * Set AF to SDP55  like  afchange 10123456789 SDP55"
echo "                  $0 SET OFFER 10123456789,ADD,200,7                 * Add Offer ID: 200   ** Expiry: After 7 Days " 
echo "                  $0 SET OFFER 10123456789,DELETE,200                * Delete Offer ID: 200 "
echo "                  $0 SET OFFER /export/home/fdsuser/Offer.list" 
echo "                  $0 SET FAF 123456789,ADD,10101010101,707           * Add FAF Number: 1010101010101  ** Indicator 707 " 
echo "                  $0 SET FAF 123456789,DLEETE,10101010101            * Delete FAF Number: 1010101010101  ** Do not Enter Indicator "
echo "                  $0 SET UC 123456789,100                            * Reset UC:100 (Format 1) "
echo "                  $0 SET UC 123456789,100,0                          * Reset UC:100 (Format 2) "
echo "                  $0 SET UC 123456789,100,RESET                      * Reset UC:100 (Format 3) "
echo "                  $0 SET UC 123456789,100,888                        * Set UC:100   ** Value:888"
echo "                  $0 SET PAM 123456789,ADD,50,507,507,1              * Add PAM Service ID: 50  ** Class: 507  *** Schedule: 507  **** Priority: 1 "
echo "                  $0 SET PAM 123456789,DELETE,50                     * Delete PAM Service ID: 50 "
echo " "
echo "                  $0 MIGRATE 010123456789"
echo "                  $0 MIGRATE /export/home/fdsuser/Migrate.list"
echo "                  $0 FORCEMIGRATE 010123456789,SDPXX"
echo "                  $0 FORCEMIGRATE /export/home/fdsuser/Migrate.list"      
sleep 4
clear
echo " "
echo " "
echo "   PARAMETERS or BATCH LIST Format "
echo " "
echo "
$bold   $0  ACTION:(GET|SET)  TYPE:(AF|INSTALL|DELETE|WRONGSDP|SC|MB|DA|DATES|COM|SOB|ACC|AG|LANG|FAF|OFFER|UC|UT|PAM)   INPUT:(MSISDN,PARAMETERS|BATCH Full Path)  $normal

MSISDN in ANY Format    002010123456789 , 010123456789 , 10123456789

 PARAMETERS in Details  or BATCH List format

SDP Account Finder            >  MSISDN,SDP                                          * SDPxx or (DEFAULT|NULL|BLANK) for Default SDP
Install MSISDN                >  MSISDN,SDP                                          * SDPxx or (DEFAULT|NULL|BLANK) for Default SDP
Delete MSISDN                 >  MSISDN
Delete MSISDN From Wrong SDP  >  MSISDN
Service Class                 >  MSISDN,SC ID
Main Balance                  >  MSISDN,MB in PT                                     * USE - to subtract    Example:   10123456789,-100    (Subtract 100 PT from MB)
Dedicated Account             >  MSISDN,DA ID,DA VALUE in PT, EXPIRY DATED           * EXPIRY ($DATE, After XX Days, null, empty or 9999 for NO Expiry)
Dates                         >  MSISDN,SUPERVISION FEE PERIOD,SERVICE FEE PERIOD
Community                     >  MSISDN,COMMUNITY ID
Service Offering Bit          >  MSISDN,SOB ID,SOB VALUE                             * Service offering Bit ID (0-31)  ** Service offering Bit Value (0-1)
Accumulators                  >  MSISDN,ACCUMULATOR ID,ACCUMULATOR VALUE             * Accumulator ID (1-99)
Account Group                 >  MSISDN,ACCOUNT GROUP ID,ACCOUNT GROUP VALUE         * Account Group ID (0-31)         ** Account Group Value (0-1)
Language                      >  MSISDN,LANGUAGE ID
Family and Friends            >  MSISDN,ADD or DELETE,FAF NUMBER,FAF INDICATOR (INCASE OF ADD ONLY)          Example: 10123456789,ADD,10101010101,707   10123456789,DELETE,10101010101      
Offer                         >  MSISDN,OFFER ID,EXPIRYDATE (INCASE OF ADD ONLY)     * EXPIRY ($DATE, After XX Days, null, empty or 9999 for NO Expiry)  Example: 10123456789,ADD,200,7
Usage Counter                 >  MSISDN,USAGE COUNTER ID,USAGE COUNTER VALUE         * Value (Number or 0, Zero, NULL RESET or BLANK to RESET) 
Usage Threshold               >  MSISDN,USAGE THRESHOLD ID,USAGE THRESHOLD VALUE     * Value (Number or 0, Zero, NULL RESET or BLANK to RESET)
Periodic Account Management   >  MSISDN,ADD or DELETE,PAM SERVICE ID,CLASS ID (INCASE OF ADD ONLY),SCHEDULE (INCASE OF ADD ONLY),PRIORITY (INCASE OF ADD ONLY)                                                                                                                                                    Example: 10123456789,ADD,50,507,507,1    10123456789,DELETE,50
"

fi

###############################################################################################################################################################################################


#################################################
#                 Get Batch                     #
#################################################
if [ $ACTION == "GET" ]&&[ $INPUT == "BATCH" ] ; then  
read -p " Please Enter MSISDN List full Path: " LIST ; cat $LIST | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST 
echo " " 

## Validate LIST ##

V_NUMF
if [ $V_NUMF -gt 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###############################################################################################################################################################################################

#################################################
#           Set Account Finder SDP              #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "AF" ] ; then

if [ $INPUT != "BATCH" ] ; then 
read -p " Please Enter New SDP (SDPXX): " SDPTMP ; SDP=`echo $SDPTMP | tr "[:lower:]" "[:upper:]"` 
echo " "
cat $WLIST | awk '{print $0",""'$SDP'"}' >  $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST


elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,SDPXX): " LIST 
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF 
V_NUMF5
V_SDP

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_NUMF5" -ne 0 ]||[ "$V_SDP" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#             INSTALL MSISDN                    #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "INSTALL" ] ; then

if [ $INPUT != "BATCH" ] ; then 
read -p " Please Enter SDP (SDPXX or type DEFAULT, NULL or BLANK for Default SDP): " SDPTMP ; SDP=`echo $SDPTMP | tr "[:lower:]" "[:upper:]"` 
echo " "
cat $WLIST | awk '{print $0",""'$SDP'"}'  | awk -F, '{if(NF<2||$2!~/./){print $1",DEFAULT"}else{print $1}}' |  sed 's/NULL/DEFAULT/g' | sed 's/BLANK/DEFAULT/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then  
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,SDP (SDPXX or type DEFAULT, NULL or blank for Default SDP): " LIST 
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | awk -F, '{if(NF<2||$2!~/./){print $0",DEFAULT"}else{print $0}}' |  sed 's/NULL/DEFAULT/g' | sed 's/BLANK/DEFAULT/g'  > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1

if [ "$V_NFCount" -ne 1 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#              Delete MSISDN                    #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "DEL" ] ; then

if [ $INPUT == "BATCH" ] ; then  
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format): " LIST ; cat $LIST > $WLIST 
echo " " 
fi

## Validate LIST ##

V_FLCount1
V_FL1
V_NUMF1

if [ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#           Delete  Wrong SDPs                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "WRONGSDP" ] ; then

log " Please confirm that Offloaded SDP list under $home/SDP.OFFLOADED is updated.. "

if [ $INPUT == "BATCH" ] ; then
read -p " Please MSISDN List full path (MSISDN in ANY Format): " LIST ; cat $LIST | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
echo " "
fi

## Validate LIST ##

V_FLCount1
V_FL1
V_NUMF1

if [ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#            Set Service Class                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "SC" ] ; then

if [ $INPUT != "BATCH" ] ; then  
read -p " Please Enter New SC ID: "  SERVICECLASSNEW 
echo " " 
cat $WLIST | awk '{print $0",""'$SERVICECLASSNEW'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then  
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,SC ID): " LIST 
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'  > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_NUMF1
V_NUMF2

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#             Set Main Balance                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "MB" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Amount to be ADDED or DEDUCTED from MB in PT: " ADJUSTMENTAMOUNTRELATIVE 
echo " "
cat $WLIST | awk '{print $0",""'$ADJUSTMENTAMOUNTRELATIVE'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST 

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,MB Amount in PT): " LIST 
echo " " 
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_NUMF1
V_NUMF2

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#           Set Dedicated Accounts              #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "DA" ] ; then

if [ $INPUT != "BATCH" ] ; then

read -p " Please Enter Dedicated Account ID: "  DAID
read -p " Please Enter Amount to be Added or Deducted in PT: "  DAAMOUNTRELATIVE
read -p " Please Enter Expiry Date ($DATE,After XX Days, null, blank, empty or 9999): "  DAEXPIRYDATETMP
echo " "

if [ -z $DAEXPIRYDATETMP ] ; then DAEXPIRYDATE=NULL ; fi
if [ ! -z $DAEXPIRYDATETMP ] ; then
if [ `echo $DAEXPIRYDATETMP | tr "[:lower:]" "[:upper:]"` == 'NULL' ]  ; then DAEXPIRYDATE=NULL ; fi
if [ `echo $DAEXPIRYDATETMP | tr "[:lower:]" "[:upper:]"` == 'EMPTY' ]  ; then DAEXPIRYDATE=NULL ; fi
if [ `echo $DAEXPIRYDATETMP | tr "[:lower:]" "[:upper:]"` == 'BLANK' ]  ; then DAEXPIRYDATE=NULL ; fi
if [ $DAEXPIRYDATE != "NULL" ]&&[ $DAEXPIRYDATETMP -gt "999" ] ; then DAEXPIRYDATE=$DAEXPIRYDATETMP ; fi
if [ $DAEXPIRYDATE != "NULL" ]&&[ $DAEXPIRYDATETMP == "9999" ] ; then DAEXPIRYDATE=99991231 ; fi
if [ $DAEXPIRYDATE != "NULL" ]&&[ $DAEXPIRYDATETMP -ge 0 ]&&[ $DAEXPIRYDATETMP -lt 1000 ] ; then

DateCalaulator $DAEXPIRYDATETMP > $tmpDir/ExpiryDate.tmp
DAEXPIRYDATE=`cat $tmpDir/ExpiryDate.tmp | awk '{print $4}'`
fi
fi
cat $WLIST | awk '{print $0",""'$DAID'"",""'$DAAMOUNTRELATIVE'"",""'$DAEXPIRYDATE'"}' >  $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,DA ID,Amount in PT,Expiry Date ($DATE, After XX Days, null, blank, empty or 9999) ): " LIST
echo " "

cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'  | sed 's/EMPTY/NULL/g' | sed 's/BLANK/NULL/g' | awk -F, '{if(NF<4||$4!~/./){print $1","$2","$3",NULL"}else{print $0}}' > $WLIST
cat $WLIST | awk -F, '{print $4}' > $tmpDir/DAEXP.tmp

IFS=$'\n'
for i in `cat $tmpDir/DAEXP.tmp | grep [0-9]` ; do

if [ $i -ge 1 ]&&[ $i -lt 1000 ] ; then
DateCalaulator $i > $tmpDir/ExpiryDate.tmp
cat $tmpDir/ExpiryDate.tmp | awk '{print "'$i'"" "$4}' >> $tmpDir/ExpiryDateMapping
fi

done

if [ -e $tmpDir/ExpiryDateMapping ] ; then
IFS=$'\n'
for i in `cat $tmpDir/ExpiryDateMapping` ; do

OldDate=`echo $i | awk '{print $1}'`
DateMapping=`echo $i | awk '{print $2}'`

cat $WLIST | sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(9999\)/\1,\2,\3,99991231/g' |  sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(NULL\)/\1,\2,\3,99991231/g' | sed "s/,$OldDate$/,$DateMapping/g"  ; done > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

else

cat $WLIST | sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(9999\)/\1,\2,\3,99991231/g' |  sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(NULL\)/\1,\2,\3,99991231/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

fi

fi

## Validate LIST ##

V_NFCount
V_NF
V_NUMF1
V_NUMF2
V_NUMF3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 4 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF1" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#                 Set Dates                     #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "DATES" ] ; then

if [ $INPUT != "BATCH" ] ; then  
read -p " Please Enter Supervision Fee Period ($DATE): " SUPERVISIONEXPIRYDATE  
read -p " Please Enter Service Fee Period ($DATE): " SERVICEFEEEXPIRYDATE  
echo " "
cat $WLIST | awk '{print $0",""'$SUPERVISIONEXPIRYDATE'"",""'$SERVICEFEEEXPIRYDATE'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Supervision Fee Period, Service Fee Period): " LIST 
echo " " 
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3
V_FLCount2 
V_FL2
V_FLCount3
V_FL3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_FLCount2" -ne 1 ]||[ "$V_FL2" -ne 8 ]||[ "$V_FLCount3" -ne 1 ]||[ "$V_FL3" -ne 8 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#               Set Community                   #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "COM" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Community ID: " COM
echo " "
cat $WLIST | awk '{print $0",""'$COM'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [$INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Community ID): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2


if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#          Set Service Offering Bits            #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "SOB" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Service offering Bit ID (1-31): " SERVICEOFFERINGID
if [ $SERVICEOFFERINGID -lt 1 ]||[ $SERVICEOFFERINGID -gt 31 ] ; then echo " " ; echo " Invaild Service offering Bit ID! " ; exit -3 ; fi

read -p " Please Enter Service offering Bit Value (0 or 1): " SERVICEOFFERINGACTIVEFLAG
if [ $SERVICEOFFERINGACTIVEFLAG -lt 0 ]||[ $SERVICEOFFERINGACTIVEFLAG -gt 1 ] ; then echo " " ; echo " Invaild Service offering Value! " ; exit -3 ; fi
echo " "
cat $WLIST | awk '{print $0",""'$SERVICEOFFERINGID'"",""'$SERVICEOFFERINGACTIVEFLAG'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Service offering Bit ID (0-31), Service offering Bit Value (0-1)): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NF
V_FLCount
V_FLCount3
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3

if [ "$V_NF" -ne 3 ]||[ "$V_FLCount3" -ne 1 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script Will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################


#################################################
#              Set Accumulators                 #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "ACC" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Accumulator ID (1-99): " ACCUMULATORID
if [ $ACCUMULATORID -lt 1 ]||[ $ACCUMULATORID -gt 99 ] ; then echo " " ; echo " Invaild ACCUMULATORID ID! " ; exit -3 ; fi
read -p " Please Enter Accumulator Value : " ACCUMULATORVALUEABSOLUTE 
echo " "
cat $WLIST | awk '{print $0",""'$ACCUMULATORID'"",""'$ACCUMULATORVALUEABSOLUTE'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Accumulator ID (1-99), Accumulator Value): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#              Set Account Group                #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "AG" ] ; then

if [ $INPUT != "BATCH" ] ; then

read -p " Please Enter Account Group ID (1-31): " ACCOUNTGROUPID
if [ $ACCOUNTGROUPID -lt 1 ]||[ $ACCOUNTGROUPID -gt 31 ] ; then echo " " ; echo " Invaild Account Group ID! " ; exit -3 ; fi
read -p " Please Enter Account Group Value (0 or 1): " ACCOUNTGROUPACTIVEFLAG
if [ $ACCOUNTGROUPACTIVEFLAG -lt 0 ]||[ $ACCOUNTGROUPACTIVEFLAG -gt 1 ] ; then echo " " ; echo " Invaild Account Group Value! " ; exit -3 ; fi
echo " "
cat $WLIST | awk '{print $0",""'$ACCOUNTGROUPID'"",""'$ACCOUNTGROUPACTIVEFLAG'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Account Group (0-31), Account Group Value (0-1) ): " LIST
echo " " 
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_FLCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3
V_FLCount3
V_FL3

if [ "$V_FLCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_FLCount3" -ne 1 ]||[ "$V_FL3" -ne 1 ]  ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#                 Set Language                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "LANG" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Language ID: " LANG
echo " "
cat $WLIST | awk '{print $0",""'$LANG'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then 
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Language ID): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#          Set Family and Friends               #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "FAF" ] ; then

if [ $INPUT != "BATCH" ] ; then

read -p " Please Enter Add or Delete: " FAFACTIONTMP
FAFACTION=`echo $FAFACTIONTMP | tr "[:lower:]" "[:upper:]"`
read -p " Please Enter FAF number: " FAFNUMBER

if [ `echo $FAFACTION  | tr "[:lower:]" "[:upper:]" ` == "ADD" ] ; then
read -p " Please Enter FAF Indicator: " FAFINDICATOR
fi
echo " "
if [[ -z $FAFINDICATOR ]] ; then FAFINDICATOR=0 ; fi
cat $WLIST | awk '{print $0",""'$FAFACTION'"",""'$FAFNUMBER'"",""'$FAFINDICATOR'"}' | sed 's/\([0-9]*\),\(0020\)\(.*\)/\1,\3/g' | sed 's/\([0-9]*\),\(0\)\(.*\)/\1,\3/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp | awk -F, '{if(NF<4||$2!~/./){print $0",0"}else{print $0}}' > $WLIST

elif [ $INPUT == "BATCH" ] ; then  
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,ADD or DELETE, FAF Number, FAF Indicator (in case of ADD ONLY): " LIST 
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | sed 's/\([0-9]*\),\(0020\)\(.*\)/\1,\3/g' | sed 's/\([0-9]*\),\(0\)\(.*\)/\1,\3/g' | awk -F, '{print $1","$2","$3","$4}' > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF3
V_NUMF4
V_ADDDEL

if  [ $FAFACTION = ADD ]&&[ "$V_NF" -ne 4 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if  [ $FAFACTION = DELETE ]&&[ "$V_NF" -ne 4 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ "$V_NFCount" -ne 1 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_NUMF4" -ne 0 ]||[ "$V_ADDDEL" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#                  Set Offers                   #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "OFFER" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Add or Delete: " OFFERACTIONTMP
OFFERACTION=`echo $OFFERACTIONTMP | tr "[:lower:]" "[:upper:]"`
if [ `echo $OFFERACTION | egrep "ADD|DELETE" | wc -l ` -ne 1 ] ;  then echo " " ; echo "  Invaild Input! " ; exit -3 ; fi
read -p " Please Enter OFFER ID: " OFFERID
if [ `echo $OFFERACTION  | tr "[:lower:]" "[:upper:]" ` == "ADD" ] ; then
read -p " Please Enter Offer Expiry Date ($DATE, After XX Days,  or NULL, BLANK or 9999 for NO expiry): " EXPIRYDATE
echo " "
fi

if [ `echo $OFFERACTION  | tr "[:lower:]" "[:upper:]" ` == "ADD" ] ; then
cat $WLIST | awk '{print $0",""'$OFFERACTION'"",""'$OFFERID'"",""'$EXPIRYDATE'"}'  | awk -F, '{if(NF<4||$4!~/./){print $1","$2","$3",99991231"}else{print $0}}' | sed 's/,9999$/,99991231/g' | sed 's/NULL/99991231/g' | sed 's/BLANK/99991231/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST
else
cat $WLIST | awk '{print $0",""'$OFFERACTION'"",""'$OFFERID'"}'  > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST
fi

elif [ $INPUT == "BATCH" ]&&[ $ACTION == "SET" ]&&[ $TYPE == "OFFER" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,ADD or DELETE, Offer ID, Offer Expiry Date ($DATE, After XX Days,  or NULL, BLANK or 9999 for NO expiry): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | awk -F, '{if(NF<4||$4!~/./){print $1","$2","$3",99991231"}else{print $0}}' | sed 's/,9999$/,99991231/g' |  sed 's/NULL/99991231/g' | sed 's/BLANK/99991231/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF3
V_NUMF4
V_ADDDEL

if [ "$OFFERACTION" == "ADD" ]&&[ "$V_NF" -ne 4 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi 
if [ "$OFFERACTION" == "DELETE" ]&&[ "$V_NF" -ne 3 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ "$V_NFCount" -ne 1 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_NUMF4" -ne 0 ]||[ "$V_ADDDEL" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#              Set Usage Counters               #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "UC" ] ; then

if [ $INPUT != "BATCH" ] ; then

read -p " Please Enter Usage Counter ID: " USAGECOUNTERID
read -p " Please Enter Usage Counter Value (0, Zero, NULL, RESET or BLANK to reset): "  USAGECOUNTERVALUENEW
echo " "
cat $WLIST | tr "[:lower:]" "[:upper:]" | awk '{print $0",""'$USAGECOUNTERID'"",""'$USAGECOUNTERVALUENEW'"}'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'   > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Usage Counter ID, Usage Counter Value (0, Zero, NULL, RESET or BLANK to reset): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST
fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1  
V_NUMF3  

#if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
fi

###########################################################################################################################################################################################

#################################################
#              Set Usage Threshold              #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "UT" ] ; then 

if [ $INPUT != "BATCH" ] ; then

read -p " Please Enter Usage Threshold ID: "  USAGETHRESHOLDID
read -p " Please Enter Usage Threshold Value: (0, Zero, NULL, RESET or BLANK to reset): " USAGETHRESHOLDVALUENEW 
echo " "
cat $WLIST | tr "[:lower:]" "[:upper:]" | awk '{print $0",""'$USAGETHRESHOLDID'"",""'$USAGETHRESHOLDVALUENEW'"}'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'   > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format, Usage Threshold ID, Usage Threshold Value ( 0, Zero, NULL or BLANK  ): " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

fi

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#        Set Periodic Account Management        #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "PAM" ] ; then

if [ $INPUT != "BATCH" ] ; then
read -p " Please Enter Add or Delete: " PAMACTIONTMP
PAMACTION=`echo $PAMACTIONTMP | tr "[:lower:]" "[:upper:]"`
if [ `echo $PAMACTION | egrep "ADD|DELETE" | wc -l ` -ne 1 ] ;  then echo " " ; echo "  Invaild Input! " ; exit -3 ; fi
read -p " Please Enter PAM Service ID:  " PAMSERVICEID
if [ `echo $PAMACTION  | tr "[:lower:]" "[:upper:]" ` == "ADD" ] ; then
read -p " Please Enter PAM Class ID: "  PAMCLASSID
read -p " Please Enter PAM Schedule ID: "  SCHEDULEID
read -p " Please Enter PAM Priority:  " PAMSERVICEPRIORITY
echo " "
fi
cat $WLIST | tr "[:lower:]" "[:upper:]" | awk '{print $0",""'$PAMACTION'"",""'$PAMSERVICEID'"",""'$PAMCLASSID'"",""'$SCHEDULEID'"",""'$PAMSERVICEPRIORITY'"}'  > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

elif [ $INPUT == "BATCH" ]&&[ $ACTION == "SET" ]&&[ $TYPE == "PAM" ] ; then
read -p " Please Enter MSISDN List full path (MSISDN in ANY Format,ADD or DELETE, PAM Service ID, PAM Class ID, PAM Schedule ID, PAM Priority) : " LIST
echo " "
cat $LIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' > $WLIST
fi

## Validate LIST ##

V_FLCount1
V_NF
V_FL1
V_NUMF1
V_NUMF3
V_NUMF4
V_NUMF5
V_NUMF6
V_ADDDEL

if  [ $PAMACTION = ADD ]&&[ "$V_NF" -ne 6 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if  [ $PAMACTION = DELETE ]&&[ "$V_NF" -ne 3 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_NUMF4" -ne 0 ]||[ "$V_NUMF5" -ne 0 ]||[ "$V_NUMF6" -ne 0 ]||[ "$V_ADDDEL" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###############################################################################################################################################################################################
###########                                                           LISTS ARE READY NOW, ACTIONS WILL START..                                                                     ###########
###############################################################################################################################################################################################


##################################################################################################
##                                 Get Account Finder SDP                                        ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "AF" ] ; then 
log Get Account Finder SDP
log ' '
##################################################################################################
IFS=$'\n'                                 
for i in `cat $WLIST` ; do                
MSISDN=$i                                         
##################################################################################################


afwhere $MSISDN

echo " $MSISDN  Current: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`"
echo " $MSISDN  Current: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`" >>$oDir/$LogFile
log ' '
done
fi

##################################################################################################
##                                     Get Account Details                                      ##
##################################################################################################
if [ $ACTION == "GET" ] ; then
if [ $TYPE == "SC" ]||[ $TYPE == "DATES" ]||[ $TYPE == "COM" ]||[ $TYPE == "SOB" ]||[ $TYPE == "AG" ]||[ $TYPE == "LANG" ]||[ $TYPE == "PAM" ] ; then

if [ $TYPE == "SC" ] ; then log Get Service Class ; log ' ' ; fi
if [ $TYPE == "DATES" ] ; then log Get Dates ; log ' ' ; fi
if [ $TYPE == "COM" ] ; then log Get Community ; log ' ' ; fi
if [ $TYPE == "SOB" ] ; then log Get Service Offering Bits ; log ' ' ; fi 
if [ $TYPE == "AG" ] ; then log Get Account Agroup ; log ' ' ; fi
if [ $TYPE == "LANG" ] ; then log Get Language ; log ' ' ; fi
if [ $TYPE == "PAM" ] ; then log  Get Periodic Account Managemenet ; log ' ' ; fi

log ' '
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GADCOUNT=`cat $UCIP/GAD | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GAD.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GAD | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GADCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GAD.sh
$tmpDir/GAD.sh > $tmpDir/GAD.out

GADresponseCode=`cat $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GADresponseCode ]] ; then GADresponseCode=-100 ; fi

if [ $GADresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Account Details Response $GADresponseCode ! " ; log ' ' ; fi


dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="serviceClassCurrent" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/SC

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="supervisionExpiryDate" | grep value | sed 's/\(<.*><.*>\)\(.[0-9].*\)\(<.*><.*>\)/\2/g' | sed 's/ //g'  | awk -F'+' '{print $1}' > $tmpDir/SupervisionExp

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="serviceFeeExpiryDate" | grep value | sed 's/\(<.*><.*>\)\(.[0-9].*\)\(<.*><.*>\)/\2/g' | sed 's/ //g'  | awk -F'+' '{print $1}' > $tmpDir/ServiceFeeExp

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=2 s="accountGroupID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/AG

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=5 s="serviceOfferingActiveFlag" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/SOB.tmp ; cat $tmpDir/SOB.tmp | paste - - > $tmpDir/SOB

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="communityID" | grep value | grep [0-9] | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/Community

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=13 s="pamClassID" | grep value | grep [0-9] | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/PAM.tmp ; cat $tmpDir/PAM.tmp | paste - - - - > $tmpDir/PAM

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="languageIDCurrent" | grep value | grep [0-9] | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/LANG

if [ $ACTION == "GET" ] ; then
if [ $TYPE == "SC" ] ; then echo " $MSISDN  SC:  `cat $tmpDir/SC`" ; echo " $MSISDN  SC:  `cat $tmpDir/SC`" >>$oDir/$LogFile ; fi 
if [ $TYPE == "DATES" ] ; then echo " $MSISDN  Supervision Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'`\n $MSISDN  Service Fee Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'` " ; echo " $MSISDN  Supervision Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'`\n$MSISDN  Service Fee Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'` " >>$oDir/$LogFile ; fi
if [ $TYPE == "COM" ] ; then echo " $MSISDN  Community ID:  `cat $tmpDir/Community`" ; echo " $MSISDN  Community ID:  `cat $tmpDir/Community`"  >>$oDir/$LogFile ; fi
if [ $TYPE == "SOB" ] ; then echo " $MSISDN  SOBs:\n\nID\tValue\n`cat $tmpDir/SOB | awk '{print $2"\t"$1}'`" ; echo " $MSISDN  SOBs:\n\nID\tValue\n`cat $tmpDir/SOB | awk '{print $2"\t"$1}'`" >>$oDir/$LogFile ; fi
if [ $TYPE == "LANG" ] ; then echo " $MSISDN  Language ID: `cat $tmpDir/LANG`" ; echo " $MSISDN  Language ID: `cat $tmpDir/LANG`" >>$oDir/$LogFile ; fi
if [ $TYPE == "PAM" ] ; then echo " $MSISDN  PAM:\n\nPAM Service\tPAM Class\tPriority\tSchedule\n`cat $tmpDir/PAM | awk '{print $2"\t\t"$1"\t\t"$3"\t\t"$4}'`" ; echo " $MSISDN  PAM:\n\nPAM Service\tPAM Class\tPriority\tSchedule\n`cat $tmpDir/PAM | awk '{print $2"\t\t"$1"\t\t"$3"\t\t"$4}'`" >>$oDir/$LogFile ; fi

if [ $TYPE == "AG" ] ; then 

###
cat << EOF >  $tmpDir/AG_BIN.pl
perl -e 'printf "%031b\n", `cat $tmpDir/AG | sed 's/ //g'`'
EOF
chmod 777 $tmpDir/AG_BIN.pl
$tmpDir/AG_BIN.pl > $tmpDir/AGBINARY
###

echo " $MSISDN  AccountGroup: `cat $tmpDir/AG`  Binary: `cat $tmpDir/AGBINARY`"
echo " $MSISDN  AccountGroup: `cat $tmpDir/AG`  Binary: `cat $tmpDir/AGBINARY`" >>$oDir/$LogFile
fi


fi
log ' '
done
fi
fi

##################################################################################################
##                                    Get Balance and Dates                                     ##
##################################################################################################
if [ $ACTION == "GET" ] ; then                  
if [ $TYPE == "MB" ]||[ $TYPE == "DA" ] ; then  
if [ $TYPE == "MB" ] ; then log Get Main Balance ; else log Get Dedicated Accounts ; fi
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
##################################################################################################

GBALDATECOUNT=`cat $UCIP/GBALDATE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GBALDATE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GBALDATE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GBALDATECOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GBALDATE.sh
$tmpDir/GBALDATE.sh > $tmpDir/GBALDATE.out

GBALDATEresponseCode=`cat $tmpDir/GBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GBALDATEresponseCode ]] ; then GBALDATEresponseCode=-100 ; fi

if [ $GBALDATEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Balance and Dates Response $GBALDATEresponseCode ! " ; log ' ' ; fi

dos2unix $tmpDir/GBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="accountValue1" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/MB

dos2unix $tmpDir/GBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="dedicatedAccountID" | grep -v dedicatedAccount | grep -v expiryDate | grep -v member | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/\(<.*><.*>\)\(.[0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/DA.tmp ; cat $tmpDir/DA.tmp | paste - - - > $tmpDir/DA 


if [ $TYPE == "MB" ] ; then echo " $MSISDN  Main Balance: `cat $tmpDir/MB` PT " ; echo " $MSISDN  Main Balance: `cat $tmpDir/MB` PT " >>$oDir/$LogFile ; fi
if [ $TYPE == "DA" ] ; then echo " $MSISDN  Dedicated Accounts:\n\nID\tValue\tExpiry\n`cat $tmpDir/DA`" ; echo " $MSISDN  Dedicated Accounts:\n\nID\tValue\tExpiry\n`cat $tmpDir/DA`" >>$oDir/$LogFile ; fi

log ' '
done
fi
fi

##################################################################################################
##                                     Get Accumulators                                         ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "ACC" ] ; then 
log Get Accumulators
log ' '
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GACCCOUNT=`cat $UCIP/GACC | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GACC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GACC | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GACCCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GACC.sh
$tmpDir/GACC.sh > $tmpDir/GACC.out

GACCresponseCode=`cat $tmpDir/GACC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GACCresponseCode ]] ; then GACCresponseCode=-100 ; fi

if [ $GACCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Accumulators Response $GACCresponseCode ! " ; echo " " ; fi

dos2unix $tmpDir/GACC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="accumulatorID" |grep -v date |  grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/ACC.tmp ; cat $tmpDir/ACC.tmp | paste - - > $tmpDir/ACC

echo " $MSISDN  Accumulators:\n\nID\tValue\n`cat $tmpDir/ACC`" 
echo " $MSISDN  Accumulators:\n\nID\tValue\n`cat $tmpDir/ACC`" >>$oDir/$LogFile

log ' '
done
fi
##################################################################################################
##                                    Get Family and Friends                                    ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "FAF" ] ; then 
log Get Family and Friends
log ' '
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GFAFCOUNT=`cat $UCIP/GFAF | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GFAF.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GFAF | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GFAFCOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GFAF.sh
$tmpDir/GFAF.sh > $tmpDir/GFAF.out

GFAFresponseCode=`cat $tmpDir/GFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GFAFresponseCode ]] ; then GFAFresponseCode=-100 ; fi


if [ $GFAFresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Family and Friends Response $GFAFresponseCode ! " ; log ' ' ; fi

dos2unix $tmpDir/GFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=6 s="fafIndicator" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/FAF.tmp ; cat $tmpDir/FAF.tmp | paste - -  > $tmpDir/FAF

echo " $MSISDN  Family and Friends:\n\nMember\tIndicator\n`cat $tmpDir/FAF | awk '{print $2"\t"$1}'`"
echo " $MSISDN  Family and Friends:\n\nMember\tIndicator\n`cat $tmpDir/FAF | awk '{print $2"\t"$1}'`" >>$oDir/$LogFile

log ' '
done
fi

##################################################################################################
##                                           Get Offers                                         ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "OFFER" ] ; then 
log Get Offers
log ' '
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GOFFERCOUNT=`cat $UCIP/GOFFER | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GOFFER.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GOFFER | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GOFFERCOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GOFFER.sh
$tmpDir/GOFFER.sh > $tmpDir/GOFFER.out

GOFFERresponseCode=`cat $tmpDir/GOFFER.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GOFFERresponseCode ]] ; then GOFFERresponseCode=-100 ; fi


if [ $GOFFERresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Offers Response $GOFFERresponseCode ! " ; log ' ' ; fi

dos2unix $tmpDir/GOFFER.out| nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="expiryDate" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' |sed 's/ //g' > $tmpDir/OFFERS.tmp ; cat $tmpDir/OFFERS.tmp | paste - - - > $tmpDir/OFFER


echo " $MSISDN  Offers:\n\nID\t\tExpiry Date\n`cat $tmpDir/OFFER | awk '{print $2"\t"$1}'`"
echo " $MSISDN  Offers:\n\nID\t\tExpiry Date\n`cat $tmpDir/OFFER | awk '{print $2"\t"$1}'`" >>$oDir/$LogFile

log ' '

done
fi

##################################################################################################
##                           Get Usage Conters and Thresholds                                   ##
##################################################################################################
if [ $ACTION == "GET" ] ; then                  
if [ $TYPE == "UC" ]||[ $TYPE == "UT" ] ; then  
if [ $TYPE == "UC" ] ; then log Get Usage Conters  ; log ' ' ; else log Get Usage Thresholds ; log ' ' ; fi
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GUCUTCOUNT=`cat $UCIP/GUCUT | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GUCUT.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GUCUT | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GUCUTCOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GUCUT.sh
$tmpDir/GUCUT.sh > $tmpDir/GUCUT.out

GUCUTresponseCode=`cat $tmpDir/GUCUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GUCUTresponseCode ]] ; then GUCUTresponseCode=-100 ; fi

if [ $GUCUTresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Usage Counter and Usage Threshold Response $GUCUTresponseCode ! "  ; echo " " ; fi

dos2unix $tmpDir/GUCUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=6 s="usageCounterID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' |sed 's/ //g' > $tmpDir/UUC.tmp ; cat $tmpDir/UUC.tmp | paste - - > $tmpDir/UC

dos2unix $tmpDir/GUCUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="usageThresholdID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' |sed 's/ //g' > $tmpDir/UUT.tmp ; cat $tmpDir/UUT.tmp | paste - - - > $tmpDir/UT

if [ $TYPE == "UC" ] ; then echo " $MSISDN  Usage Counters:\n\nID\tValue\n`cat $tmpDir/UC`" ; fi
if [ $TYPE == "UT" ] ; then echo " $MSISDN  Usage Thresholds:\n\nID\tValue\n`cat $tmpDir/UT | awk '{print $1"\t"$3}'`" ; fi
if [ $TYPE == "UC" ] ; then echo " $MSISDN  Usage Counters:\n\nID\tValue\n`cat $tmpDir/UC`" >>$oDir/$LogFile ; fi
if [ $TYPE == "UT" ] ; then echo " $MSISDN  Usage Thresholds:\n\nID\tValue\n`cat $tmpDir/UT | awk '{print $1"\t"$3}'`" >>$oDir/$LogFile ; fi
log ' '
done
fi
fi

##################################################################################################
##                                 Set Account Finder SDP                                       ##
##################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "AF" ] ; then 
##################################################################################################
log Set Account Finder SDP
log ' '
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`
##################################################################################################

afchange $MSISDN $SDP
sleep 3

echo " $MSISDN  New: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`"
echo " $MSISDN  New: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`" >>$oDir/$LogFile
log ' '
done
fi

##################################################################################################
##                                    Install MSISDN                                            ## 
##################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "INSTALL" ] ; then
log Install MSISDN
log ' '
##################################################################################################
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`
##################################################################################################

if [ -z $SDP ] ; then SDP=DEFAULT ; fi
if [ $SDP == "NULL" ] ; then SDP=DEFAULT ; fi
if [ $SDP == "BLANK" ] ; then SDP=DEFAULT ; fi


afwhere $MSISDN

##  Deleting From Current SDP  ##


SDPCURRENT=`cat $tmpDir/SDP.current`
SDPDEFAULT=`cat $tmpDir/SDP.default`

DELETECOUNT=`cat $UCIP/DELETE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DELETE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DELETE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$DELETECOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DELETE.sh
$tmpDir/DELETE.sh > $tmpDir/DELETE.out

DELETEresponseCode=`cat $tmpDir/DELETE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DELETEresponseCode ]] ; then DELETEresponseCode=-100 ; fi

log " $MSISDN  Deleting MSISDN from Current $SDPCURRENT response Code is  $DELETEresponseCode"
#if [ $DELETEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete MSISDN from Current $SDPCURRENT Response $DELETEresponseCode ! " ; log ' '  ; fi

####


if [ $SDP == "DEFAULT" ] ; then SDP=`cat $tmpDir/SDP.default` ; fi

if [ $SDP != `cat $tmpDir/SDP.current` ] ; then afchange $MSISDN $SDP ; sleep 2 ; fi

## Delete before Installing on New SDP ##
DELETECOUNT=`cat $UCIP/DELETE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DELETE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DELETE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$DELETECOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DELETE.sh
$tmpDir/DELETE.sh > $tmpDir/DELETE.out

DELETEresponseCode=`cat $tmpDir/DELETE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`

## Install on New SDP ##

afchange 
SERVICECLASSNEW=1
INSTALLCOUNT_TMP=`cat $UCIP/INSTALL | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m | sed 's/ //g'`
INSTALLCOUNT=`expr $INSTALLCOUNT_TMP - 1`

cat << EOF > $tmpDir/INSTALL.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/INSTALL | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$INSTALLCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/INSTALL.sh
$tmpDir/INSTALL.sh > $tmpDir/INSTALL.out

INSTALLresponseCode=`cat $tmpDir/INSTALL.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $INSTALLresponseCode ]] ; then INSTALLresponseCode=-100 ; fi

log " $MSISDN  Installing MSISDN On New $SDP response Code is  $INSTALLresponseCode"
if [ $INSTALLresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Install MSISDN on New $SDP Response $INSTALLresponseCode ! " ; log ' ' ; fi

####
done
fi

###################################################################################################
##                                Delete MSISDN                                                  ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "DEL" ] ; then
log Delete MSISDN from SDP
log ' '
###################################################################################################
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`
###################################################################################################


##  Deleting From Current SDP  ##


DELETECOUNT=`cat $UCIP/DELETE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DELETE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DELETE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$DELETECOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DELETE.sh
$tmpDir/DELETE.sh > $tmpDir/DELETE.out

DELETEresponseCode=`cat $tmpDir/DELETE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DELETEresponseCode ]] ; then DELETEresponseCode=-100 ; fi

log " $MSISDN  Deleting MSISDN from SDP response Code is  $DELETEresponseCode"
if [ $DELETEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete MSISDN from SDP Response $DELETEresponseCode ! " ; log ' ' ; fi
log ' '
done
fi

###################################################################################################
##                                     Delete Wrong SDPs                                         ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "WRONGSDP" ] ; then
###################################################################################################

cat $WLIST > $wd/DeleteWrongSDPs.MSISDN.list
nohup ./DeleteWrongSDPs.sh  $AFIP $AFUser $AFPass  2>/dev/null &
log ' '
log " Delete MSISDN from Wrong SDPs Requested.. "
log ' '
log " Please Check Log file $oDir/DeleteWrongSDPs_`date +%Y%m%d`.log "

fi

###################################################################################################
##                                      Set Service Class                                        ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "SC" ] ; then 
log Set Service Class
###################################################################################################
if [ $INPUT != "BATCH" ]; then cat $WLIST | awk '{print $0",""'$SERVICECLASSNEW'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST ; fi
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SERVICECLASSNEW=`echo $i | awk -F, '{print $2}'`
###################################################################################################

GADCOUNT=`cat $UCIP/GAD | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GAD.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GAD | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GADCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GAD.sh
$tmpDir/GAD.sh > $tmpDir/GAD.out

GADresponseCode=`cat $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GADresponseCode ]] ; then GADresponseCode=-100 ; fi

if [ $GADresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Account Details Response $GADresponseCode ! " ; log ' ' ; fi


dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="serviceClassCurrent" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/SC

SERVICECLASSCURRENT=`cat $tmpDir/SC`

USCCount=`cat $UCIP/USC | sed 's/MSISDN/'"$MSISDN"'/g' |  sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/SERVICECLASSCURRENT/'"$SERVICECLASSCURRENT"'/g'  | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/USC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/USC | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$USCCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'  |  sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/SERVICECLASSCURRENT/'"$SERVICECLASSCURRENT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/USC.sh
$tmpDir/USC.sh > $tmpDir/USC.out

USCresponseCode=`cat $tmpDir/USC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $USCresponseCode ]] ; then USCresponseCode=-100 ; fi

if [ $USCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Service Class Response $USCresponseCode ! " ; log ' ' ; else log " $MSISDN  New SC $SERVICECLASSNEW     Old SC $SERVICECLASSCURRENT" ; fi
log ' '
done
fi

###################################################################################################
##                                  Update Main Balance                                          ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "MB" ] ; then 
log Update Main Balance
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
ADJUSTMENTAMOUNTRELATIVE=`echo $i | awk -F, '{print $2}'`
###################################################################################################

UMBCount=`cat $UCIP/UMB | sed 's/MSISDN/'"$MSISDN"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UMB.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UMB | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UMBCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UMB.sh
$tmpDir/UMB.sh > $tmpDir/UMB.out

UMBresponseCode=`cat $tmpDir/UMB.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UMBresponseCode ]] ; then UMBresponseCode=-100 ; fi
if [ $ADJUSTMENTAMOUNTRELATIVE -ge 0 ] ; then Message=`echo $ADJUSTMENTAMOUNTRELATIVE PT added to MB` ; else Message=`echo $ADJUSTMENTAMOUNTRELATIVE PT deducted from MB` ; fi 
if [ $UMBresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Main Balance Response $UMBresponseCode ! " ; log ' ' ; else log " $MSISDN  $Message" ; fi
log ' '

done
fi

###################################################################################################
##                                        Update Dedicated Accounts                              ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "DA" ] ; then 
log Update Dedicated Accounts
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
DAID=`echo $i | awk -F, '{print $2}'`
DAAMOUNTRELATIVE=`echo $i | awk -F, '{print $3}'`
DAEXPIRYDATE=`echo $i | awk -F, '{print $4}'`
###################################################################################################

if [ $DAEXPIRYDATE == "NULL" ] ;then

UDACount=`cat $UCIP/UDA | grep -v DAEXPIRYDATE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UDA.$DAID.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UDA | sed  's/\\"/\\\"/g'  | grep -v DAEXPIRYDATE | sed 's/COUNT/'"$UDACount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UDA.$DAID.sh
$tmpDir/UDA.$DAID.sh > $tmpDir/UDA.$DAID.out

UDAresponseCode=`cat $tmpDir/UDA.$DAID.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UDAresponseCode ]] ; then UDAresponseCode=-100 ; fi
if [ $DAAMOUNTRELATIVE -ge 0 ] ; then Message=`echo $DAAMOUNTRELATIVE PT added to DA $DAID with Expiry Date $DAEXPIRYDATE ` ; else Message=`echo $DAAMOUNTRELATIVE PT deducted from DA $DAID` ; fi
if [ $UDAresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Dedicated Accounts $DAID Response $UDAresponseCode ! " ; log ' ' ; else log " $MSISDN  $Message" ; fi



else

UDACount=`cat $UCIP/UDA | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UDA.$DAID.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UDA | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UDACount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UDA.$DAID.sh
$tmpDir/UDA.$DAID.sh > $tmpDir/UDA.$DAID.out

UDAresponseCode=`cat $tmpDir/UDA.$DAID.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UDAresponseCode ]] ; then UDAresponseCode=-100 ; fi
if [ $DAAMOUNTRELATIVE -ge 0 ] ; then Message=`echo $DAAMOUNTRELATIVE PT added to DA $DAID with Expiry Date $DAEXPIRYDATE ` ; else Message=`echo $DAAMOUNTRELATIVE PT deducted from DA $DAID` ; fi
if [ $UDAresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Dedicated Accounts $DAID Response $UDAresponseCode ! " ; log ' ' ; else log " $MSISDN  $Message" ; fi

fi
done
fi

###################################################################################################
##                                              Update Dates                                     ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "DATES" ] ; then
log Update Dates
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SUPERVISIONEXPIRYDATE=`echo $i | awk -F, '{print $2"T00:00:00"}'`
SERVICEFEEEXPIRYDATE=`echo $i | awk -F, '{print $3"T00:00:00"}'`
SUPERVISIONEXPIRYDATE2=`echo $i | awk -F, '{print $2}'`
SERVICEFEEEXPIRYDATE2=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UBALDATECount=`cat $UCIP/UBALDATE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ADJUSTMENTAMOUNTRELATIVE/0/g' |  sed 's/SUPERVISIONEXPIRYDATE/'"$SUPERVISIONEXPIRYDATE"'/g' |  sed 's/SERVICEFEEEXPIRYDATE/'"$SERVICEFEEEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UBALDATE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UBALDATE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UBALDATECount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ADJUSTMENTAMOUNTRELATIVE/0/g' | sed 's/SUPERVISIONEXPIRYDATE/'"$SUPERVISIONEXPIRYDATE"'/g' |  sed 's/SERVICEFEEEXPIRYDATE/'"$SERVICEFEEEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UBALDATE.sh
$tmpDir/UBALDATE.sh > $tmpDir/UBALDATE.out

UBALDATEresponseCode=`cat $tmpDir/UBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UBALDATEresponseCode ]] ; then UBALDATEresponseCode=-100 ; fi
if [ $UBALDATEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Dates Response $UBALDATEresponseCode ! " ; log ' ' ; else log " $MSISDN  Service Fee Period: $SERVICEFEEEXPIRYDATE2 Supervision Fee Period: $SUPERVISIONEXPIRYDATE2 dates have been set. " ; fi 

log ' '

done
fi

###################################################################################################
##                                        Update Community                                       ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "COM" ] ; then #
log Update Community
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
COMMUNITYID=`echo $i | awk -F, '{print $2}'`
###################################################################################################

UCOMCount=`cat $UCIP/UCOM | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/COMMUNITYID/'"$COMMUNITYID"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UCOM.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UCOM | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UCOMCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/COMMUNITYID/'"$COMMUNITYID"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UCOM.sh
$tmpDir/UCOM.sh > $tmpDir/UCOM.out

UCOMresponseCode=`cat $tmpDir/UCOM.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UCOMresponseCode ]] ; then UCOMresponseCode=-100 ; fi
if [ $UCOMresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Community Response $UCOMresponseCode ! " ; log ' ' ; else log " $MSISDN  Community ID $COMMUNITYID has been set. " ; fi

log ' '
done
fi

###################################################################################################
##                            Set Service Offering Bits                                          ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "SOB" ] ; then 
log Set Service Offering Bits
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SERVICEOFFERINGID=`echo $i | awk -F, '{print $2}'`
SERVICEOFFERINGACTIVEFLAG=`echo $i | awk -F, '{print $3}'`
###################################################################################################

USOBCount=`cat $UCIP/USOB | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICEOFFERINGID/'"$SERVICEOFFERINGID"'/g'| sed 's/SERVICEOFFERINGACTIVEFLAG/'"$SERVICEOFFERINGACTIVEFLAG"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/USOB.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/USOB | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$USOBCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICEOFFERINGID/'"$SERVICEOFFERINGID"'/g'| sed 's/SERVICEOFFERINGACTIVEFLAG/'"$SERVICEOFFERINGACTIVEFLAG"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/USOB.sh
$tmpDir/USOB.sh > $tmpDir/USOB.out

USOBresponseCode=`cat $tmpDir/USOB.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $USOBresponseCode ]] ; then USOBresponseCode=-100 ; fi
if [ $SERVICEOFFERINGACTIVEFLAG -eq 1 ] ; then message="Set" ; else message="Cleared" ; fi
if [ $USOBresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update SOB Response $USOBresponseCode ! " ; log ' ' ;  else log " $MSISDN  SOB ID $SERVICEOFFERINGID has been $message. " ; fi

log ' '
done
fi

###################################################################################################
##                                  Update Accumulators                                          ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "ACC" ] ; then 
log Update Accumulators
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
ACCUMULATORID=`echo $i | awk -F, '{print $2}'`
ACCUMULATORVALUEABSOLUTE=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UACCCount=`cat $UCIP/UACC | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCUMULATORID/'"$ACCUMULATORID"'/g'| sed 's/ACCUMULATORVALUEABSOLUTE/'"$ACCUMULATORVALUEABSOLUTE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UACC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UACC | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UACCCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCUMULATORID/'"$ACCUMULATORID"'/g'| sed 's/ACCUMULATORVALUEABSOLUTE/'"$ACCUMULATORVALUEABSOLUTE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UACC.sh 
$tmpDir/UACC.sh > $tmpDir/UACC.out

UACCresponseCode=`cat $tmpDir/UACC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UACCresponseCode ]] ; then UACCresponseCode=-100 ; fi
if [ $UACCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update ACcumulator Response $UACCresponseCode ! " ; log ' ' ; else log " $MSISDN  Accumulator ID $ACCUMULATORID has been set to $ACCUMULATORVALUEABSOLUTE. " ; fi

log ' '
done
fi

###################################################################################################
##                                         Update Account Group                                  ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "AG" ] ; then 
log Update Account Group
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
ACCOUNTGROUPID=`echo $i | awk -F, '{print $2}'`
ACCOUNTGROUPACTIVEFLAG=`echo $i | awk -F, '{print $3}'`
ACCOUNTGROUPIDOUT=`echo $i | awk -F, '{print $2}'`
ACCOUNTGROUPACTIVEFLAGOUT=`echo $i | awk -F, '{print $3}'`
###################################################################################################

## CURRENT AG ##
GADCOUNT=`cat $UCIP/GAD | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GAD.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GAD | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GADCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GAD.sh
$tmpDir/GAD.sh > $tmpDir/GAD.out

GADresponseCode=`cat $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GADresponseCode ]] ; then GADresponseCode=-100 ; fi

if [ $GADresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Account Details Response $GADresponseCode ! " ; log ' '  ; fi

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=2 s="accountGroupID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/AGcurrent


###
cat << EOF >  $tmpDir/AG_BIN.pl
perl -e 'printf "%031b\n", `cat $tmpDir/AGcurrent | sed 's/ //g'`'
EOF
chmod 777 $tmpDir/AG_BIN.pl
$tmpDir/AG_BIN.pl > $tmpDir/AGcurrentBINARY
###

################

AGmask=`expr 32 - $ACCOUNTGROUPID`
AGnewBINARY=`cat $tmpDir/AGcurrentBINARY | sed 's/./'"$ACCOUNTGROUPACTIVEFLAG"'/'"$AGmask"''`


###
cat << EOF >  $tmpDir/AG_NEW_DEC.pl
perl -e 'printf "%0d\n", 0b`echo $AGnewBINARY | sed 's/ //g'`'
EOF
chmod 777 $tmpDir/AG_NEW_DEC.pl
$tmpDir/AG_NEW_DEC.pl > $tmpDir/AGnewBINARY
###


ACCOUNTGROUPID=`cat $tmpDir/AGnewBINARY`

################
 
UAGCount=`cat $UCIP/UAG | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCOUNTGROUPID/'"$ACCOUNTGROUPID"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UAG.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UAG | sed  's/\\"/\\\"/g'  | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCOUNTGROUPID/'"$ACCOUNTGROUPID"'/g'| sed 's/COUNT/'"$UAGCount"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UAG.sh
$tmpDir/UAG.sh > $tmpDir/UAG.out

UAGresponseCode=`cat $tmpDir/UAG.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UAGresponseCode ]] ; then UAGresponseCode=-100 ; fi
if [ $ACCOUNTGROUPACTIVEFLAGOUT -eq 1 ] ; then message="Set" ; else message="Cleared" ; fi
if [ $UAGresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Account Group Response $UAGresponseCode ! " ; log ' ' ;  else log " $MSISDN  Account Group ID $ACCOUNTGROUPIDOUT has been $message . " ; fi

done
fi

###################################################################################################
##                                           Update Language                                     ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "LANG" ] ; then
log Update Language
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
LANGUAGEIDNEW=`echo $i | awk -F, '{print $2}'`
###################################################################################################

ULANGCount=`cat $UCIP/ULANG | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/LANGUAGEIDNEW/'"$LANGUAGEIDNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/ULANG.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/ULANG | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/LANGUAGEIDNEW/'"$LANGUAGEIDNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$ULANGCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/ULANG.sh
$tmpDir/ULANG.sh > $tmpDir/ULANG.out

ULANGresponseCode=`cat $tmpDir/ULANG.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $ULANGresponseCode ]] ; then ULANGresponseCode=-100 ; fi
if [ $ULANGresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Language Response $ULANGresponseCode ! " ;  else log " $MSISDN  Language ID $LANGUAGEIDNEW has been set. " ; fi

log ' '
done
fi

###################################################################################################
##                                      Update Family and Friends                                ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "FAF" ] ; then #
log Update Family and Friends
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
FAFACTION=`echo $i | awk -F, '{print $2}'`
FAFNUMBER=`echo $i | awk -F, '{print $3}'`
FAFINDICATOR=`echo $i | awk -F, '{print $4}'`
if [[ -z $FAFINDICATOR ]] ; then FAFINDICATOR=0 ; fi
###################################################################################################

if [ $FAFACTION == 'ADD' ] ; then

UFAFCount=`cat $UCIP/UFAF | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g'| sed 's/FAFINDICATOR/'"$FAFINDICATOR"'/g'  | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UFAF.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UFAF | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g' | sed 's/FAFINDICATOR/'"$FAFINDICATOR"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UFAFCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UFAF.sh
$tmpDir/UFAF.sh > $tmpDir/UFAF.out

UFAFresponseCode=`cat $tmpDir/UFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UFAFresponseCode ]] ; then UFAFresponseCode=-100 ; fi
if [ $UFAFresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Family and Friends Response $UFAFresponseCode ! " ; log ' ' ; else log " $MSISDN  Family Member $FAFNUMBER has been Added. " ; fi



else



DFAFCount=`cat $UCIP/DFAF | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DFAF.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DFAF | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$DFAFCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DFAF.sh
$tmpDir/DFAF.sh > $tmpDir/DFAF.out

DFAFresponseCode=`cat $tmpDir/DFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DFAFresponseCode ]] ; then DFAFresponseCode=-100 ; fi
if [ $DFAFresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete Family and Friends Response $DFAFresponseCode ! " ; log ' ' ; else log " $MSISDN  Family Member $FAFNUMBER has been Deleted. " ; fi

fi
log ' '
done
fi

###################################################################################################
##                                   Update Offers                                               ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "OFFER" ] ; then 
log Update Offers  
log ' '
###################################################################################################

for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
OFFERACTION=`echo $i | awk -F, '{print $2}'`
OFFERID=`echo $i | awk -F, '{print $3}'`
EXPIRYDATE=`echo $i | awk -F, '{print $4}'`

if [ $OFFERACTION == 'ADD' ] ; then
if [ $EXPIRYDATE -gt 0 ]&&[ $EXPIRYDATE -lt 1000 ] ; then DateCalaulator $EXPIRYDATE > $tmpDir/EXPIRYDATE ; EXPIRYDATE=`cat $tmpDir/EXPIRYDATE | awk '{print $4}'` ; fi


UOFFERCountTMP=`cat $UCIP/UOFFER | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g'| sed 's/EXPIRYDATE/'"$EXPIRYDATE"'/g'  | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`
UOFFERCount=`expr $UOFFERCountTMP - 1`

cat << EOF > $tmpDir/UOFFER.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UOFFER | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g' | sed 's/EXPIRYDATE/'"$EXPIRYDATE"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UOFFERCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UOFFER.sh
$tmpDir/UOFFER.sh > $tmpDir/UOFFER.out

UOFFERresponseCode=`cat $tmpDir/UOFFER.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UOFFERresponseCode ]] ; then UOFFERresponseCode=-100 ; fi
if [ $UOFFERresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Offer $OFFERID Expiry Date $EXPIRYDATE Response $UOFFERresponseCode ! " ; log ' ' ;  else log " $MSISDN  Offer $OFFERID with Expiry Date $EXPIRYDATE has been Added. " ; fi

else

DOFFERCountTMP=`cat $UCIP/DOFFER | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`
DOFFERCount=`expr $DOFFERCountTMP - 1`


cat << EOF > $tmpDir/DOFFER.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DOFFER | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$DOFFERCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DOFFER.sh
$tmpDir/DOFFER.sh > $tmpDir/DOFFER.out

DOFFERresponseCode=`cat $tmpDir/DOFFER.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DOFFERresponseCode ]] ; then DOFFERresponseCode=-100 ; fi
if [ $DOFFERresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete Offer $OFFERID Response $DOFFERresponseCode ! " ; log ' ' ;  else log " $MSISDN  Offer $OFFERID has been Deleted. " ; fi

fi
log ' '
done
fi


###################################################################################################
##                                 Update Usage Counters                                         ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "UC" ] ; then
log Update Usage Counters  
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
USAGECOUNTERID=`echo $i | awk -F, '{print $2}'`
USAGECOUNTERVALUENEW=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UUCCount=`cat $UCIP/UUC | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGECOUNTERID/'"$USAGECOUNTERID"'/g'  | sed 's/USAGECOUNTERVALUENEW/'"$USAGECOUNTERVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UUC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UUC | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGECOUNTERID/'"$USAGECOUNTERID"'/g' | sed 's/USAGECOUNTERVALUENEW/'"$USAGECOUNTERVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UUCCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UUC.sh
$tmpDir/UUC.sh > $tmpDir/UUC.out

UUCresponseCode=`cat $tmpDir/UUC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UUCresponseCode ]] ; then UUCresponseCode=-100 ; fi
if [ $UUCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Usage Counter $USAGECOUNTERID Response $UUCresponseCode ! " ; log ' ' ; else log " $MSISDN  Usage Counter ID $USAGECOUNTERID has been set to $USAGECOUNTERVALUENEW. " ; fi

log ' '
done
fi

###################################################################################################
##                                    Update Usage Thresholds                                    ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "UT" ] ; then    
log  Update Usage Thresholds 
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
USAGETHRESHOLDID=`echo $i | awk -F, '{print $2}'`
USAGETHRESHOLDVALUENEW=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UUTCount=`cat $UCIP/UUT | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGETHRESHOLDID/'"$USAGETHRESHOLDID"'/g'  | sed 's/USAGETHRESHOLDVALUENEW/'"$USAGETHRESHOLDVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UUT.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UUT | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGETHRESHOLDID/'"$USAGETHRESHOLDID"'/g' | sed 's/USAGETHRESHOLDVALUENEW/'"$USAGETHRESHOLDVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UUTCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UUT.sh
$tmpDir/UUT.sh > $tmpDir/UUT.out

UUTresponseCode=`cat $tmpDir/UUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UUTresponseCode ]] ; then UUTresponseCode=-100 ; fi
if [ $UUTresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Usage Threshold $USAGETHRESHOLDID Response $UUTresponseCode ! " ; log ' ' ;  else log " $MSISDN  Usage Threshold ID $USAGETHRESHOLDID has been set to $USAGETHRESHOLDVALUENEW. " ; fi

done
fi

###################################################################################################
##                          Set Periodic Account Management                                      ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "PAM" ] ; then
log Set Periodic Account Management
log ' '
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
PAMACTION=`echo $i | awk -F, '{print $2}'`
PAMSERVICEID=`echo $i | awk -F, '{print $3}'`
PAMCLASSID=`echo $i | awk -F, '{print $4}'`
SCHEDULEID=`echo $i | awk -F, '{print $5}'`
PAMSERVICEPRIORITY=`echo $i | awk -F, '{print $6}'`
###################################################################################################

if [ $PAMACTION = 'ADD' ] ; then

UPAMCountTMP=`cat $UCIP/UPAM | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

UPAMCount=`expr $UPAMCountTMP - 1 `

cat << EOF > $tmpDir/UPAM.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UPAM | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UPAMCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UPAM.sh
$tmpDir/UPAM.sh > $tmpDir/UPAM.out

UPAMresponseCode=`cat $tmpDir/UPAM.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UPAMresponseCode ]] ; then UPAMresponseCode=-100 ; fi
if [ $UPAMresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update PAM $PAMSERVICEID Response $UPAMresponseCode ! " ; log ' ' ; else log " $MSISDN  PAM ID $PAMSERVICEID Class $PAMCLASSID Schedule $SCHEDULEID Priority $PAMSERVICEPRIORITY has been added. " ; fi


else

DPAMCountTMP=`cat $UCIP/DPAM | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

DPAMCount=`expr $DPAMCountTMP - 1 `

cat << EOF > $tmpDir/DPAM.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DPAM | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$DPAMCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DPAM.sh
$tmpDir/DPAM.sh > $tmpDir/DPAM.out

DPAMresponseCode=`cat $tmpDir/DPAM.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DPAMresponseCode ]] ; then DPAMresponseCode=-100 ; fi
if [ $DPAMresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete PAM $PAMSERVICEID Response $DPAMresponseCode ! " ; log ' ' ; else log " $MSISDN  PAM ID $PAMSERVICEID has been deleted. " ; fi

fi
done
fi
log ' '
fi ## HELP=YES






if [ $SKIP == 'YES' ]&&[ $HELP == 'NO' ] ; then
echo " "

#################################################
#               MSISDN Migration                #
#################################################

if [ $ACTION == "MIGRATE" ] ; then 

## Validate LIST ##

V_FLCount
V_FL
V_NUMF

if [ "$V_FLCount" -ne 1 ]||[ "$V_FL" -ne 10 ]||[ "$V_NUMF" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

## Start Migration ##

for i in `cat $WLIST` ; do
log " $i  Migration Started.. "
log ' '  
$home/migrate.sh $i $AFIP $AFUser $AFPass $AirIP $AirUser $AirPass $tmpDir
done

fi

#################################################
#            MSISDN Force Migration             #
#################################################

if [ $ACTION == "FORCEMIGRATE" ] ; then

## Validate LIST ##

V_FLCount
V_FL1
V_NFCount

if [ "$V_FLCount" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NFCount" -ne 1 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

## Start Migration ##

for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`

log " $MSISDN  $SDP  Migration Started.. "
log ' '

$home/migrate.sh $MSISDN $AFIP $AFUser $AFPass $AirIP $AirUser $AirPass $SDP $tmpDir
done

fi

###############################################################################################################################################################################################


#################################################
#                 Get Batch                     #
#################################################

if [ $ACTION == "GET" ]&&[ $INPUT == "BATCH" ] ; then  
log Get Account Details
log ' '

## Validate LIST ##

V_NUMF

if [ $V_NUMF -gt 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###############################################################################################################################################################################################

#################################################
#           Set Account Finder                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "AF" ] ; then
log Set Account Finder
log ' '

## Validate LIST ##

V_NFCount
V_NF 
V_NUMF5
V_SDP

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_NUMF5" -ne 0 ]||[ "$V_SDP" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#             INSTALL MSISDN                    #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "INSTALL" ] ; then
log INSTALL MSISDN
log ' '


cat $WLIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | awk -F, '{if(NF<2||$2!~/./){print $0",DEFAULT"}else{print $0}}' |  sed 's/NULL/DEFAULT/g' | sed 's/BLANK/DEFAULT/g'  > $WLIST

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NULL

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NULL" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#              Delete MSISDN                    #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "DEL" ] ; then
log Delete MSISDN
log ' '
## Validate LIST ##

V_FLCount1
V_FL1
V_NUMF1

if [ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#           Delete  Wrong SDPs                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "WRONGSDP" ] ; then

log " Please confirm that Offloaded SDP list under $home/SDP.OFFLOADED is updated.. "

## Validate LIST ##

V_FLCount1
V_FL1
V_NUMF1

if [ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#            Set Service Class                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "SC" ] ; then
log Set Service Class
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_NUMF1
V_NUMF2

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#             Set Main Balance                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "MB" ] ; then
log Set Main Balance
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_NUMF1
V_NUMF2

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#           Set Dedicated Accounts              #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "DA" ] ; then
log Set Dedicated Accounts
log ' '

cat $WLIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g'  | sed 's/EMPTY/NULL/g' | sed 's/BLANK/NULL/g' | awk -F, '{if(NF<4||$4!~/./){print $1","$2","$3",NULL"}else{print $0}}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST
cat $WLIST | awk -F, '{print $4}' > $tmpDir/DAEXP.tmp

IFS=$'\n'
for i in `cat $tmpDir/DAEXP.tmp | grep [0-9]` ; do

if [ $i -ge 1 ]&&[ $i -lt 1000 ] ; then
DateCalaulator $i > $tmpDir/ExpiryDate.tmp
cat $tmpDir/ExpiryDate.tmp | awk '{print "'$i'"" "$4}' >> $tmpDir/ExpiryDateMapping
fi

done

if [ -e $tmpDir/ExpiryDateMapping ] ; then
IFS=$'\n'
for i in `cat $tmpDir/ExpiryDateMapping` ; do

OldDate=`echo $i | awk '{print $1}'`
DateMapping=`echo $i | awk '{print $2}'`

cat $WLIST | sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(9999\)/\1,\2,\3,99991231/g' |  sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(NULL\)/\1,\2,\3,99991231/g' | sed "s/,$OldDate$/,$DateMapping/g"  ; done > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

else

cat $WLIST | sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(9999\)/\1,\2,\3,99991231/g' |  sed 's/\([0-9]*\),\([0-9]*\),\([0-9]*\),\(NULL\)/\1,\2,\3,99991231/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

fi


## Validate LIST ##

V_NFCount
V_NF
V_NUMF1
V_NUMF2
V_NUMF3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 4 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF1" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi
###########################################################################################################################################################################################

#################################################
#                 Set Dates                     #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "DATES" ] ; then
log Set Dates 
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3
V_FLCount2 
V_FL2
V_FLCount3
V_FL3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_FLCount2" -ne 1 ]||[ "$V_FL2" -ne 8 ]||[ "$V_FLCount3" -ne 1 ]||[ "$V_FL3" -ne 8 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#               Set Community                   #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "COM" ] ; then
log Set Community
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2


if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#          Set Service Offering Bits            #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "SOB" ] ; then
log Set Service Offering Bits 
log ' '

## Validate LIST ##

V_NF
V_FLCount1
V_FLCount3
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3

if [ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FLCount3" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script Will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################


#################################################
#              Set Accumulators                 #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "ACC" ] ; then
log Set Accumulators
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#              Set Account Group                #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "AG" ] ; then
log Set Account Group 
log ' '

## Validate LIST ##

V_FLCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2
V_NUMF3
V_FLCount3
V_FL3

if [ "$V_FLCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_FLCount3" -ne 1 ]||[ "$V_FL3" -ne 1 ]  ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#                 Set Language                  #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "LANG" ] ; then
log  Set Language 
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF2

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 2 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF2" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#          Set Family and Friends               #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "FAF" ] ; then
log Set Family and Friends  
log ' '

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF3
V_NUMF4
V_ADDDEL

if [ "$V_NFCount" -ne 1 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_NUMF4" -ne 0 ]||[ "$V_ADDDEL" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###########################################################################################################################################################################################

#################################################
#                  Set Offers                   #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "OFFER" ] ; then
log Set Offers  
log ' '

cat $WLIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | awk -F, '{if(NF<4||$4!~/./){print $1","$2","$3",99991231"}else{print $0}}' | sed 's/,9999$/,99991231/g' |  sed 's/NULL/99991231/g' | sed 's/BLANK/99991231/g' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1
V_NUMF3
V_NUMF4
V_ADDDEL

if  [ "$OFFERACTION" == "ADD" ]&&[ "$V_NF" -ne 4 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi 
if  [ "$OFFERACTION" == "DELETE" ]&&[ "$V_NF" -ne 3 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ "$V_NFCount" -ne 1 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_NUMF4" -ne 0 ]||[ "$V_ADDDEL" -ne 0 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi
###########################################################################################################################################################################################

#################################################
#              Set Usage Counters               #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "UC" ] ; then
log Set Usage Counters
log ' '

cat $WLIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1  

#if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
fi

###########################################################################################################################################################################################

#################################################
#              Set Usage Threshold              #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "UT" ] ; then 
log Set Usage Threshold 
log ' '

cat $WLIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

## Validate LIST ##

V_NFCount
V_NF
V_FLCount1
V_FL1
V_NUMF1  
V_NUMF3  

if [ "$V_NFCount" -ne 1 ]||[ "$V_NF" -ne 3 ]||[ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
fi
###########################################################################################################################################################################################

#################################################
#        Set Periodic Account Management        #
#################################################

if [ $ACTION == "SET" ]&&[ $TYPE == "PAM" ] ; then
log Set Periodic Account Management  
log ' '

cat $WLIST | tr "[:lower:]" "[:upper:]" | sed 's/^01/1/g' | sed 's/^201/1/g' | sed 's/^00201/1/g' | sed 's/ZERO/0/g' | sed 's/NULL/0/g' | sed 's/RESET/0/g' | sed 's/BLANK/0/g'  | awk -F, '{if(NF<3||$3!~/./){print $1","$2",0"}else{print $0}}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST

## Validate LIST ##

V_FLCount1
V_NF
V_FL1
V_NUMF1
V_NUMF3
V_NUMF4
V_NUMF5
V_NUMF6
V_ADDDEL

if  [ "$PAMACTION" == "ADD" ]&&[ "$V_NF" -ne 6 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if  [ "$PAMACTION" == "DELETE" ]&&[ "$V_NF" -ne 3 ]; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi
if [ "$V_FLCount1" -ne 1 ]||[ "$V_FL1" -ne 10 ]||[ "$V_NUMF1" -ne 0 ]||[ "$V_NUMF3" -ne 0 ]||[ "$V_NUMF4" -ne 0 ]||[ "$V_NUMF5" -ne 0 ]||[ "$V_NUMF6" -ne 0 ]||[ "$V_ADDDEL" -ne 0 ] ; then  log ' Invalid List!  Script will  STOP! ' ; log ' ' ; exit -3 ; fi

fi

###############################################################################################################################################################################################
###########                                                           LISTS ARE READY NOW, ACTIONS WILL START..                                                                     ###########
###############################################################################################################################################################################################


##################################################################################################
##                                 Gett Account Finder SDP                                      ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "AF" ] ; then 
log Gett Account Finder SDP
log ' '
IFS=$'\n'                                 
for i in `cat $WLIST` ; do                
MSISDN=$i                                         
##################################################################################################

afwhere $MSISDN

echo " $MSISDN  Current: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`" 
echo " $MSISDN  Current: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`" >>$oDir/$LogFile

log ' '
done
fi

##################################################################################################
##                                     Get Account Details                                      ##
##################################################################################################
if [ $ACTION == "GET" ] ; then
if [ $TYPE == "SC" ]||[ $TYPE == "DATES" ]||[ $TYPE == "COM" ]||[ $TYPE == "SOB" ]||[ $TYPE == "AG" ]||[ $TYPE == "LANG" ]||[ $TYPE == "PAM" ] ; then

if [ $TYPE == "SC" ] ; then log Get Service Class ; log ' ' ; fi
if [ $TYPE == "DATES" ] ; then log Get Dates ; log ' ' ; fi
if [ $TYPE == "COM" ] ; then log Get Community ; log ' ' ; fi
if [ $TYPE == "SOB" ] ; then log Get Service Offering Bits ; log ' ' ; fi 
if [ $TYPE == "AG" ] ; then log Get Account Agroup ; log ' ' ; fi
if [ $TYPE == "LANG" ] ; then log Get Language ; log ' ' ; fi
if [ $TYPE == "PAM" ] ; then log  Get Periodic Account Managemenet ; log ' ' ; fi
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GADCOUNT=`cat $UCIP/GAD | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GAD.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GAD | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GADCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GAD.sh
$tmpDir/GAD.sh > $tmpDir/GAD.out

GADresponseCode=`cat $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GADresponseCode ]] ; then GADresponseCode=-100 ; fi

if [ $GADresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Account Details Response $GADresponseCode ! " ; log ' ' ; fi


dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="serviceClassCurrent" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/SC

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="supervisionExpiryDate" | grep value | sed 's/\(<.*><.*>\)\(.[0-9].*\)\(<.*><.*>\)/\2/g' | sed 's/ //g'  | awk -F'+' '{print $1}' > $tmpDir/SupervisionExp

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="serviceFeeExpiryDate" | grep value | sed 's/\(<.*><.*>\)\(.[0-9].*\)\(<.*><.*>\)/\2/g' | sed 's/ //g'  | awk -F'+' '{print $1}' > $tmpDir/ServiceFeeExp

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=2 s="accountGroupID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/AG

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=5 s="serviceOfferingActiveFlag" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/SOB.tmp ; cat $tmpDir/SOB.tmp | paste - - > $tmpDir/SOB

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="communityID" | grep value | grep [0-9] | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/Community

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=13 s="pamClassID" | grep value | grep [0-9] | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/PAM.tmp ; cat $tmpDir/PAM.tmp | paste - - - - > $tmpDir/PAM

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="languageIDCurrent" | grep value | grep [0-9] | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/LANG

if [ $ACTION == "GET" ] ; then
if [ $TYPE == "SC" ] ; then echo " $MSISDN  SC:  `cat $tmpDir/SC`" ; echo " $MSISDN  SC:  `cat $tmpDir/SC`" >>$oDir/$LogFile ; fi 
if [ $TYPE == "DATES" ] ; then echo " $MSISDN  Supervision Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'`\n $MSISDN  Service Fee Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'` " ; echo " $MSISDN  Supervision Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'`\n$MSISDN  Service Fee Expiry:  `cat $tmpDir/SupervisionExp | awk -F'T' '{print $1}'` " >>$oDir/$LogFile; fi
if [ $TYPE == "COM" ] ; then echo " $MSISDN  Community ID:  `cat $tmpDir/Community`" ; echo " $MSISDN  Community ID:  `cat $tmpDir/Community`" >>$oDir/$LogFile ; fi
if [ $TYPE == "SOB" ] ; then echo " $MSISDN  SOBs:\n\nID\tValue\n`cat $tmpDir/SOB | awk '{print $2"\t"$1}'`" ; echo " $MSISDN  SOBs:\n\nID\tValue\n`cat $tmpDir/SOB | awk '{print $2"\t"$1}'`" >>$oDir/$LogFile ; fi
if [ $TYPE == "LANG" ] ; then echo " $MSISDN  Language ID: `cat $tmpDir/LANG`" ; echo " $MSISDN  Language ID: `cat $tmpDir/LANG`" >>$oDir/$LogFile ; fi
if [ $TYPE == "PAM" ] ; then echo " $MSISDN  PAM:\n\nPAM Service\tPAM Class\tPriority\tSchedule\n`cat $tmpDir/PAM | awk '{print $2"\t\t"$1"\t\t"$3"\t\t"$4}'`" ; echo " $MSISDN  PAM:\n\nPAM Service\tPAM Class\tPriority\tSchedule\n`cat $tmpDir/PAM | awk '{print $2"\t\t"$1"\t\t"$3"\t\t"$4}'`" >>$oDir/$LogFile ; fi

if [ $TYPE == "AG" ] ; then 

###
cat << EOF >  $tmpDir/AG_BIN.pl
perl -e 'printf "%031b\n", `cat $tmpDir/AG | sed 's/ //g'`'
EOF
chmod 777 $tmpDir/AG_BIN.pl
$tmpDir/AG_BIN.pl > $tmpDir/AGBINARY
###

echo " $MSISDN  AccountGroup: `cat $tmpDir/AG`  Binary: `cat $tmpDir/AGBINARY`"
echo " $MSISDN  AccountGroup: `cat $tmpDir/AG`  Binary: `cat $tmpDir/AGBINARY`" >>$oDir/$LogFile
fi


fi
log ' '
done
fi
fi

##################################################################################################
##                                    Get Balance and Dates                                     ##
##################################################################################################
if [ $ACTION == "GET" ] ; then                  
if [ $TYPE == "MB" ]||[ $TYPE == "DA" ] ; then  
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
##################################################################################################

GBALDATECOUNT=`cat $UCIP/GBALDATE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GBALDATE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GBALDATE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GBALDATECOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GBALDATE.sh
$tmpDir/GBALDATE.sh > $tmpDir/GBALDATE.out

GBALDATEresponseCode=`cat $tmpDir/GBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GBALDATEresponseCode ]] ; then GBALDATEresponseCode=-100 ; fi

if [ $GBALDATEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Balance and Dates Response $GBALDATEresponseCode ! "  ; echo " " ; fi

dos2unix $tmpDir/GBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="accountValue1" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/MB

dos2unix $tmpDir/GBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="dedicatedAccountID" | grep -v dedicatedAccount | grep -v expiryDate | grep -v member | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/\(<.*><.*>\)\(.[0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/DA.tmp ; cat $tmpDir/DA.tmp | paste - - - > $tmpDir/DA 


if [ $TYPE == "MB" ] ; then echo " $MSISDN  Main Balance: `cat $tmpDir/MB` PT " ; echo " $MSISDN  Main Balance: `cat $tmpDir/MB` PT "  >>$oDir/$LogFile ; fi
if [ $TYPE == "DA" ] ; then echo " $MSISDN  Dedicated Accounts:\n\nID\tValue\tExpiry\n`cat $tmpDir/DA`" ; echo " $MSISDN  Dedicated Accounts:\n\nID\tValue\tExpiry\n`cat $tmpDir/DA`" >>$oDir/$LogFile ; fi

log ' '
done
fi
fi

##################################################################################################
##                                     Get Accumulators                                         ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "ACC" ] ; then 
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GACCCOUNT=`cat $UCIP/GACC | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GACC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GACC | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GACCCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GACC.sh
$tmpDir/GACC.sh > $tmpDir/GACC.out

GACCresponseCode=`cat $tmpDir/GACC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GACCresponseCode ]] ; then GACCresponseCode=-100 ; fi

if [ $GACCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Accumulators Response $GACCresponseCode !" ; echo " " ; fi

dos2unix $tmpDir/GACC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="accumulatorID" |grep -v date |  grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/ACC.tmp ; cat $tmpDir/ACC.tmp | paste - - > $tmpDir/ACC

echo " $MSISDN  Accumulators:\n\nID\tValue\n`cat $tmpDir/ACC`"
echo " $MSISDN  Accumulators:\n\nID\tValue\n`cat $tmpDir/ACC`" >>$oDir/$LogFile

log ' '
done
fi
##################################################################################################
##                                    Get Family and Friends                                    ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "FAF" ] ; then 
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GFAFCOUNT=`cat $UCIP/GFAF | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GFAF.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GFAF | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GFAFCOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GFAF.sh
$tmpDir/GFAF.sh > $tmpDir/GFAF.out

GFAFresponseCode=`cat $tmpDir/GFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GFAFresponseCode ]] ; then GFAFresponseCode=-100 ; fi


if [ $GFAFresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Family and Friends Response $GFAFresponseCode ! "  ; echo " " ; fi

dos2unix $tmpDir/GFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=6 s="fafindicator" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/FAF.tmp ; cat $tmpDir/FAF.tmp | paste - -  > $tmpDir/FAF

echo " $MSISDN  Family and Friends:\n\nMember\tIndicator\n`cat $tmpDir/FAF | awk '{print $2"\t"$1}'`"
echo " $MSISDN  Family and Friends:\n\nMember\tIndicator\n`cat $tmpDir/FAF | awk '{print $2"\t"$1}'`" >>$oDir/$LogFile 

log ' '
done
fi

##################################################################################################
##                                           Get Offers                                         ##
##################################################################################################
if [ $ACTION == "GET" ]&&[ $TYPE == "OFFER" ] ; then 
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GOFFERCOUNT=`cat $UCIP/GOFFER | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GOFFER.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GOFFER | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GOFFERCOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GOFFER.sh
$tmpDir/GOFFER.sh > $tmpDir/GOFFER.out

GOFFERresponseCode=`cat $tmpDir/GOFFER.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GOFFERresponseCode ]] ; then GOFFERresponseCode=-100 ; fi


if [ $GOFFERresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Offers Response $GOFFERresponseCode ! "  ; echo " " ; fi

dos2unix $tmpDir/GOFFER.out| nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="expiryDate" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' |sed 's/ //g' > $tmpDir/OFFERS.tmp ; cat $tmpDir/OFFERS.tmp | paste - - - > $tmpDir/OFFER

echo " $MSISDN  Offers:\n\nID\t\tExpiry Date\n`cat $tmpDir/OFFER | awk '{print $2"\t"$1}'`"
echo " $MSISDN  Offers:\n\nID\t\tExpiry Date\n`cat $tmpDir/OFFER | awk '{print $2"\t"$1}'`" >>$oDir/$LogFile
log ' '

done
fi

##################################################################################################
##                           Get Usage Conters and Thresholds                                   ##
##################################################################################################
if [ $ACTION == "GET" ] ; then                  
if [ $TYPE == "UC" ]||[ $TYPE == "UT" ] ; then  
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=$i
##################################################################################################

GUCUTCOUNT=`cat $UCIP/GUCUT | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GUCUT.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GUCUT | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GUCUTCOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GUCUT.sh
$tmpDir/GUCUT.sh > $tmpDir/GUCUT.out

GUCUTresponseCode=`cat $tmpDir/GUCUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GUCUTresponseCode ]] ; then GUCUTresponseCode=-100 ; fi

if [ $GUCUTresponseCode -ne 0 ] ; then log " $MSISDN  Invalid  Usage Counter and Usage Threshold Response $GUCUTresponseCode ! "  ; echo " " ; fi

dos2unix $tmpDir/GUCUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=6 s="usageCounterID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' |sed 's/ //g' > $tmpDir/UUC.tmp ; cat $tmpDir/UUC.tmp | paste - - > $tmpDir/UC

dos2unix $tmpDir/GUCUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=9 s="usageThresholdID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' |sed 's/ //g' > $tmpDir/UUT.tmp ; cat $tmpDir/UUT.tmp | paste - - - > $tmpDir/UT

if [ $TYPE == "UC" ] ; then echo " $MSISDN  Usage Counters:\n\nID\tValue\n`cat $tmpDir/UC`" ; echo " $MSISDN  Usage Counters:\n\nID\tValue\n`cat $tmpDir/UC`" >>$oDir/$LogFile ; fi
if [ $TYPE == "UT" ] ; then echo " $MSISDN  Usage Thresholds:\n\nID\tValue\n`cat $tmpDir/UT | awk '{print $1"\t"$3}'`" ; echo " $MSISDN  Usage Thresholds:\n\nID\tValue\n`cat $tmpDir/UT | awk '{print $1"\t"$3}'`" >>$oDir/$LogFile ; fi

log ' '
done
fi
fi

##################################################################################################
##                                          Setting SDPs                                        ##
##################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "AF" ] ; then 
##################################################################################################
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`
##################################################################################################

afchange $MSISDN $SDP
sleep 3

echo " $MSISDN  New: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`"
echo " $MSISDN  New: `cat $tmpDir/SDP.current`      Range: `cat $tmpDir/SDP.default`" >>$oDir/$LogFile

log ' '
done
fi

##################################################################################################
##                                    Install MSISDN                                            ## 
##################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "INSTALL" ] ; then
##################################################################################################
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`
##################################################################################################

if [ -z $SDP ] ; then SDP=DEFAULT ; fi
if [ $SDP == "NULL" ] ; then SDP=DEFAULT ; fi
if [ $SDP == "BLANK" ] ; then SDP=DEFAULT ; fi

afwhere $MSISDN

##  Deleting From Current SDP  ##


SDPCURRENT=`cat $tmpDir/SDP.current`
SDPDEFAULT=`cat $tmpDir/SDP.default`

DELETECOUNT=`cat $UCIP/DELETE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DELETE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DELETE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$DELETECOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DELETE.sh
$tmpDir/DELETE.sh > $tmpDir/DELETE.out

DELETEresponseCode=`cat $tmpDir/DELETE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DELETEresponseCode ]] ; then DELETEresponseCode=-100 ; fi

log " $MSISDN  Deleting MSISDN from Current $SDPCURRENT response Code is  $DELETEresponseCode"
#if [ $DELETEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete MSISDN from Current $SDPCURRENT Response $DELETEresponseCode ! " ; log ' '  ; fi

####


if [ $SDP == "DEFAULT" ] ; then SDP=`cat $tmpDir/SDP.default` ; fi

if [ $SDP != `cat $tmpDir/SDP.current` ] ; then
cat << EOF > $tmpDir/SDP.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AFIP
    expect "login: "
    send "$AirUser\r"
    expect "Password: "
    send "$AirPass\r"
    expect "$ "
    send "afchange $MSISDN $SDP\r"
    expect "$ "
    send "sleep 3\r"
    expect "$ "
    send "exit\r"

EOF
chmod 777 $tmpDir/SDP.sh
$tmpDir/SDP.sh > $tmpDir/afchange.out
fi

## Delete before Installinf on Nes SDP ##
DELETECOUNT=`cat $UCIP/DELETE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DELETE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DELETE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$DELETECOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DELETE.sh
$tmpDir/DELETE.sh > $tmpDir/DELETE.out

DELETEresponseCode=`cat $tmpDir/DELETE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`

## Install on New SDP ##

afchange
SERVICECLASSNEW=1
INSTALLCOUNT_TMP=`cat $UCIP/INSTALL | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m | sed 's/ //g'`
INSTALLCOUNT=`expr $INSTALLCOUNT_TMP - 1`

cat << EOF > $tmpDir/INSTALL.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/INSTALL | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$INSTALLCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/INSTALL.sh
$tmpDir/INSTALL.sh > $tmpDir/INSTALL.out

INSTALLresponseCode=`cat $tmpDir/INSTALL.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $INSTALLresponseCode ]] ; then INSTALLresponseCode=-100 ; fi

log " $MSISDN  Installing MSISDN On New $SDP response Code is  $INSTALLresponseCode"
if [ $INSTALLresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Install MSISDN on New $SDP Response $INSTALLresponseCode ! " ; log ' ' ; fi

####
done
fi

###################################################################################################
##                               Deleting MSISDN                                                 ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "DEL" ] ; then
###################################################################################################
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SDP=`echo $i | awk -F, '{print $2}'`
###################################################################################################


##  Deleting From Current SDP  ##


DELETECOUNT=`cat $UCIP/DELETE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DELETE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DELETE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$DELETECOUNT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DELETE.sh
$tmpDir/DELETE.sh > $tmpDir/DELETE.out

DELETEresponseCode=`cat $tmpDir/DELETE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DELETEresponseCode ]] ; then DELETEresponseCode=-100 ; fi

log " $MSISDN  Deleting MSISDN from SDP response Code is  $DELETEresponseCode"
if [ $DELETEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete MSISDN from SDP Response $DELETEresponseCode ! "  ; fi
log ' '
done
fi

###################################################################################################
##                                     Delete Wrong SDPs                                         ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "WRONGSDP" ] ; then
###################################################################################################

cat $WLIST > $wd/DeleteWrongSDPs.MSISDN.list
nohup ./DeleteWrongSDPs.sh  $AFIP $AFUser $AFPass  2>/dev/null &
log ' '
log " Delete MSISDN from Wrong SDPs Requested.. "
log ' '
log " Please Check Log file $oDir/DeleteWrongSDPs_`date +%Y%m%d`.log "

fi

###################################################################################################
##                                    Update Service Class                                       ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "SC" ] ; then 
###################################################################################################
if [ $INPUT != "BATCH" ]; then cat $WLIST | awk '{print $0",""'$SERVICECLASSNEW'"}' > $tmpDir/WLIST.tmp ; cat $tmpDir/WLIST.tmp > $WLIST ; fi
IFS=$'\n'
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SERVICECLASSNEW=`echo $i | awk -F, '{print $2}'`
###################################################################################################

GADCOUNT=`cat $UCIP/GAD | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GAD.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GAD | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GADCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GAD.sh
$tmpDir/GAD.sh > $tmpDir/GAD.out

GADresponseCode=`cat $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GADresponseCode ]] ; then GADresponseCode=-100 ; fi

if [ $GADresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Account Details Response $GADresponseCode ! " ; log ' ' ; fi


dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="serviceClassCurrent" | grep value | sed 's/\(<.*><.*>\)\(.[0-9]*\)\(<.*><.*>\)/\2/g' | sed 's/ //g' > $tmpDir/SC

SERVICECLASSCURRENT=`cat $tmpDir/SC`

USCCount=`cat $UCIP/USC | sed 's/MSISDN/'"$MSISDN"'/g' |  sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/SERVICECLASSCURRENT/'"$SERVICECLASSCURRENT"'/g'  | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/USC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/USC | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$USCCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g'  |  sed 's/SERVICECLASSNEW/'"$SERVICECLASSNEW"'/g' | sed 's/SERVICECLASSCURRENT/'"$SERVICECLASSCURRENT"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/USC.sh
$tmpDir/USC.sh > $tmpDir/USC.out

USCresponseCode=`cat $tmpDir/USC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $USCresponseCode ]] ; then USCresponseCode=-100 ; fi

if [ $USCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Service Class Response $USCresponseCode ! Script will STOP! " ; log ' ' ; else log " $MSISDN New SC $SERVICECLASSNEW     Old SC $SERVICECLASSCURRENT" ; fi

log ' '
done
fi

###################################################################################################
##                                  Update Main Balance                                          ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "MB" ] ; then 
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
ADJUSTMENTAMOUNTRELATIVE=`echo $i | awk -F, '{print $2}'`
###################################################################################################

UMBCount=`cat $UCIP/UMB | sed 's/MSISDN/'"$MSISDN"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UMB.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UMB | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UMBCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UMB.sh
$tmpDir/UMB.sh > $tmpDir/UMB.out

UMBresponseCode=`cat $tmpDir/UMB.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UMBresponseCode ]] ; then UMBresponseCode=-100 ; fi
if [ $ADJUSTMENTAMOUNTRELATIVE -ge 0 ] ; then Message=`echo $ADJUSTMENTAMOUNTRELATIVE PT added to MB` ; else Message=`echo $ADJUSTMENTAMOUNTRELATIVE PT deducted from MB` ; fi 
if [ $UMBresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Main Balance Response $UMBresponseCode ! " ; log ' ' ; else log " $MSISDN $Message" ; fi

log ' '
done
fi

###################################################################################################
##                                        Update Dedicated Accounts                              ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "DA" ] ; then 
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
DAID=`echo $i | awk -F, '{print $2}'`
DAAMOUNTRELATIVE=`echo $i | awk -F, '{print $3}'`
DAEXPIRYDATE=`echo $i | awk -F, '{print $4}'`
###################################################################################################

if [ $DAEXPIRYDATE == "NULL" ] ;then

UDACount=`cat $UCIP/UDA | grep -v DAEXPIRYDATE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UDA.$DAID.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UDA | sed  's/\\"/\\\"/g'  | grep -v DAEXPIRYDATE | sed 's/COUNT/'"$UDACount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UDA.$DAID.sh
$tmpDir/UDA.$DAID.sh > $tmpDir/UDA.$DAID.out

UDAresponseCode=`cat $tmpDir/UDA.$DAID.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UDAresponseCode ]] ; then UDAresponseCode=-100 ; fi
if [ $DAAMOUNTRELATIVE -ge 0 ] ; then Message=`echo $DAAMOUNTRELATIVE PT added to DA $DAID with Expiry Date $DAEXPIRYDATE ` ; else Message=`echo $DAAMOUNTRELATIVE PT deducted from DA $DAID` ; fi
if [ $UDAresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Dedicated Accounts $DAID Response $UDAresponseCode ! " ; log ' ' ; else log " $MSISDN $Message" ; fi



else

UDACount=`cat $UCIP/UDA | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UDA.$DAID.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UDA | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UDACount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/DAID/'"$DAID"'/g' | sed 's/DAAMOUNTRELATIVE/'"$DAAMOUNTRELATIVE"'/g' | sed 's/DAEXPIRYDATE/'"$DAEXPIRYDATE"'/g' |  sed 's/ADJUSTMENTAMOUNTRELATIVE/'"$ADJUSTMENTAMOUNTRELATIVE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UDA.$DAID.sh
$tmpDir/UDA.$DAID.sh > $tmpDir/UDA.$DAID.out

UDAresponseCode=`cat $tmpDir/UDA.$DAID.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UDAresponseCode ]] ; then UDAresponseCode=-100 ; fi
if [ $DAAMOUNTRELATIVE -ge 0 ] ; then Message=`echo $DAAMOUNTRELATIVE PT added to DA $DAID with Expiry Date $DAEXPIRYDATE ` ; else Message=`echo $DAAMOUNTRELATIVE PT deducted from DA $DAID` ; fi
if [ $UDAresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Dedicated Accounts $DAID Response $UDAresponseCode ! " ; log ' ' ; else log " $MSISDN $Message" ; fi

fi
done
fi

###################################################################################################
##                                              Update Dates                                     ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "DATES" ] ; then
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SUPERVISIONEXPIRYDATE=`echo $i | awk -F, '{print $2"T00:00:00"}'`
SERVICEFEEEXPIRYDATE=`echo $i | awk -F, '{print $3"T00:00:00"}'`
SUPERVISIONEXPIRYDATE2=`echo $i | awk -F, '{print $2}'`
SERVICEFEEEXPIRYDATE2=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UBALDATECount=`cat $UCIP/UBALDATE | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ADJUSTMENTAMOUNTRELATIVE/0/g' |  sed 's/SUPERVISIONEXPIRYDATE/'"$SUPERVISIONEXPIRYDATE"'/g' |  sed 's/SERVICEFEEEXPIRYDATE/'"$SERVICEFEEEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UBALDATE.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UBALDATE | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UBALDATECount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ADJUSTMENTAMOUNTRELATIVE/0/g' | sed 's/SUPERVISIONEXPIRYDATE/'"$SUPERVISIONEXPIRYDATE"'/g' |  sed 's/SERVICEFEEEXPIRYDATE/'"$SERVICEFEEEXPIRYDATE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UBALDATE.sh
$tmpDir/UBALDATE.sh > $tmpDir/UBALDATE.out

UBALDATEresponseCode=`cat $tmpDir/UBALDATE.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UBALDATEresponseCode ]] ; then UBALDATEresponseCode=-100 ; fi
if [ $UBALDATEresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Dates Response $UBALDATEresponseCode ! " ; log ' ' ; else log " $MSISDN  Service Fee Period: $SERVICEFEEEXPIRYDATE2 Supervision Fee Period: $SUPERVISIONEXPIRYDATE2 dates have been set. " ; fi 

log ' '
done
fi

###################################################################################################
##                                        Update Community                                       ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "COM" ] ; then #
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
COMMUNITYID=`echo $i | awk -F, '{print $2}'`
###################################################################################################

UCOMCount=`cat $UCIP/UCOM | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/COMMUNITYID/'"$COMMUNITYID"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UCOM.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UCOM | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UCOMCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/COMMUNITYID/'"$COMMUNITYID"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UCOM.sh
$tmpDir/UCOM.sh > $tmpDir/UCOM.out

UCOMresponseCode=`cat $tmpDir/UCOM.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UCOMresponseCode ]] ; then UCOMresponseCode=-100 ; fi
if [ $UCOMresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Community Response $UCOMresponseCode ! " ; log ' ' ; else log " $MSISDN  Community ID $COMMUNITYID has been set. " ; fi

log ' '
done
fi

###################################################################################################
##                                       Update SOB                                              ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "SOB" ] ; then 
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
SERVICEOFFERINGID=`echo $i | awk -F, '{print $2}'`
SERVICEOFFERINGACTIVEFLAG=`echo $i | awk -F, '{print $3}'`
###################################################################################################

USOBCount=`cat $UCIP/USOB | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICEOFFERINGID/'"$SERVICEOFFERINGID"'/g'| sed 's/SERVICEOFFERINGACTIVEFLAG/'"$SERVICEOFFERINGACTIVEFLAG"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/USOB.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/USOB | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$USOBCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/SERVICEOFFERINGID/'"$SERVICEOFFERINGID"'/g'| sed 's/SERVICEOFFERINGACTIVEFLAG/'"$SERVICEOFFERINGACTIVEFLAG"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/USOB.sh
$tmpDir/USOB.sh > $tmpDir/USOB.out

USOBresponseCode=`cat $tmpDir/USOB.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $USOBresponseCode ]] ; then USOBresponseCode=-100 ; fi
if [ $SERVICEOFFERINGACTIVEFLAG -eq 1 ] ; then message="Set" ; else message="Cleared" ; fi
if [ $USOBresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update SOB Response $USOBresponseCode ! " ; log ' ' ;  else log " $MSISDN  SOB ID $SERVICEOFFERINGID has been $message. " ; fi

log ' '
done
fi

###################################################################################################
##                                  Update Accumulators                                          ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "ACC" ] ; then 
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
ACCUMULATORID=`echo $i | awk -F, '{print $2}'`
ACCUMULATORVALUEABSOLUTE=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UACCCount=`cat $UCIP/UACC | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCUMULATORID/'"$ACCUMULATORID"'/g'| sed 's/ACCUMULATORVALUEABSOLUTE/'"$ACCUMULATORVALUEABSOLUTE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UACC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UACC | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$UACCCount"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCUMULATORID/'"$ACCUMULATORID"'/g'| sed 's/ACCUMULATORVALUEABSOLUTE/'"$ACCUMULATORVALUEABSOLUTE"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UACC.sh 
$tmpDir/UACC.sh > $tmpDir/UACC.out

UACCresponseCode=`cat $tmpDir/UACC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UACCresponseCode ]] ; then UACCresponseCode=-100 ; fi
if [ $UACCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update ACcumulator Response $UACCresponseCode ! " ; log ' ' ; else log " $MSISDN  Accumulator ID $ACCUMULATORID has been set to $ACCUMULATORVALUEABSOLUTE. " ; fi

log ' '
done
fi

###################################################################################################
##                                         Update Account Group                                  ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "AG" ] ; then 
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
ACCOUNTGROUPID=`echo $i | awk -F, '{print $2}'`
ACCOUNTGROUPACTIVEFLAG=`echo $i | awk -F, '{print $3}'`
ACCOUNTGROUPIDOUT=`echo $i | awk -F, '{print $2}'`
ACCOUNTGROUPACTIVEFLAGOUT=`echo $i | awk -F, '{print $3}'`
###################################################################################################

## CURRENT AG ##
GADCOUNT=`cat $UCIP/GAD | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/GAD.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/GAD | sed  's/\\"/\\\"/g'  | sed 's/COUNT/'"$GADCOUNT"'/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/GAD.sh
$tmpDir/GAD.sh > $tmpDir/GAD.out

GADresponseCode=`cat $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $GADresponseCode ]] ; then GADresponseCode=-100 ; fi

if [ $GADresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Get Account Details Response $GADresponseCode ! " ; log ' '  ; fi

dos2unix $tmpDir/GAD.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=2 s="accountGroupID" | grep value | sed 's/\(<.*><.*>\)\([0-9].*\)\(<.*><.*>\)/\2/g' | awk -F'T' '{print $1}' | sed 's/ //g' > $tmpDir/AGcurrent


###
cat << EOF >  $tmpDir/AG_BIN.pl
perl -e 'printf "%031b\n", `cat $tmpDir/AGcurrent | sed 's/ //g'`'
EOF
chmod 777 $tmpDir/AG_BIN.pl
$tmpDir/AG_BIN.pl > $tmpDir/AGcurrentBINARY
###

################

AGmask=`expr 32 - $ACCOUNTGROUPID`
AGnewBINARY=`cat $tmpDir/AGcurrentBINARY | sed 's/./'"$ACCOUNTGROUPACTIVEFLAG"'/'"$AGmask"''`


###
cat << EOF >  $tmpDir/AG_NEW_DEC.pl
perl -e 'printf "%0d\n", 0b`echo $AGnewBINARY | sed 's/ //g'`'
EOF
chmod 777 $tmpDir/AG_NEW_DEC.pl
$tmpDir/AG_NEW_DEC.pl > $tmpDir/AGnewBINARY
###


ACCOUNTGROUPID=`cat $tmpDir/AGnewBINARY`

################
 
UAGCount=`cat $UCIP/UAG | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCOUNTGROUPID/'"$ACCOUNTGROUPID"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UAG.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UAG | sed  's/\\"/\\\"/g'  | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/ACCOUNTGROUPID/'"$ACCOUNTGROUPID"'/g'| sed 's/COUNT/'"$UAGCount"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UAG.sh
$tmpDir/UAG.sh > $tmpDir/UAG.out

UAGresponseCode=`cat $tmpDir/UAG.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UAGresponseCode ]] ; then UAGresponseCode=-100 ; fi
if [ $ACCOUNTGROUPACTIVEFLAGOUT -eq 1 ] ; then message="Set" ; else message="Cleared" ; fi
if [ $UAGresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Account Group Response $UAGresponseCode ! " ; log ' ' ; else log " $MSISDN  Account Group ID $ACCOUNTGROUPIDOUT has been $message . " ; fi

done
fi

###################################################################################################
##                                           Update Language                                     ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "LANG" ] ; then
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
LANGUAGEIDNEW=`echo $i | awk -F, '{print $2}'`
###################################################################################################

ULANGCount=`cat $UCIP/ULANG | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/LANGUAGEIDNEW/'"$LANGUAGEIDNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/ULANG.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/ULANG | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/LANGUAGEIDNEW/'"$LANGUAGEIDNEW"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$ULANGCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/ULANG.sh
$tmpDir/ULANG.sh > $tmpDir/ULANG.out

ULANGresponseCode=`cat $tmpDir/ULANG.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $ULANGresponseCode ]] ; then ULANGresponseCode=-100 ; fi
if [ $ULANGresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Language Response $ULANGresponseCode ! " ; log ' ' ;  else log " $MSISDN  Language ID $LANGUAGEIDNEW has been set. " ; fi

log ' '
done
fi

###################################################################################################
##                                      Update Family and Friends                                ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "FAF" ] ; then #
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
FAFACTION=`echo $i | awk -F, '{print $2}'`
FAFNUMBER=`echo $i | awk -F, '{print $3}'`
FAFINDICATOR=`echo $i | awk -F, '{print $4}'`
###################################################################################################

if [ $FAFACTION == 'ADD' ] ; then

UFAFCount=`cat $UCIP/UFAF | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g'| sed 's/FAFINDICATOR/'"$FAFINDICATOR"'/g'  | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UFAF.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UFAF | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g' | sed 's/FAFINDICATOR/'"$FAFINDICATOR"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UFAFCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UFAF.sh
$tmpDir/UFAF.sh > $tmpDir/UFAF.out

UFAFresponseCode=`cat $tmpDir/UFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UFAFresponseCode ]] ; then UFAFresponseCode=-100 ; fi
if [ $UFAFresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Family and Friends Response $UFAFresponseCode ! " ; log ' ' ;  else log " $MSISDN  Family Member $FAFNUMBER has been Added. " ; fi



else



DFAFCount=`cat $UCIP/DFAF | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/DFAF.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DFAF | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/FAFNUMBER/'"$FAFNUMBER"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$DFAFCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DFAF.sh
$tmpDir/DFAF.sh > $tmpDir/DFAF.out

DFAFresponseCode=`cat $tmpDir/DFAF.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DFAFresponseCode ]] ; then DFAFresponseCode=-100 ; fi
if [ $DFAFresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete Family and Friends Response $DFAFresponseCode ! " ; log ' ' ; else log " $MSISDN  Family Member $FAFNUMBER has been Deleted. " ; fi

fi
log ' '
done
fi

###################################################################################################
##                                   Update Offers                                               ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "OFFER" ] ; then 
###################################################################################################

for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
OFFERACTION=`echo $i | awk -F, '{print $2}'`
OFFERID=`echo $i | awk -F, '{print $3}'`
EXPIRYDATE=`echo $i | awk -F, '{print $4}'`


if [ $OFFERACTION == 'ADD' ] ; then

if [ $EXPIRYDATE -gt 0 ]&&[ $EXPIRYDATE -lt 1000 ] ; then DateCalaulator $EXPIRYDATE > $tmpDir/EXPIRYDATE ; EXPIRYDATE=`cat $tmpDir/EXPIRYDATE | awk '{print $4}'` ; fi

UOFFERCountTMP=`cat $UCIP/UOFFER | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g'| sed 's/EXPIRYDATE/'"$EXPIRYDATE"'/g'  | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`
UOFFERCount=`expr $UOFFERCountTMP - 1`

cat << EOF > $tmpDir/UOFFER.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UOFFER | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g' | sed 's/EXPIRYDATE/'"$EXPIRYDATE"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UOFFERCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UOFFER.sh
$tmpDir/UOFFER.sh > $tmpDir/UOFFER.out

UOFFERresponseCode=`cat $tmpDir/UOFFER.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UOFFERresponseCode ]] ; then UOFFERresponseCode=-100 ; fi
if [ $UOFFERresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Offer $OFFERID Expiry Date $EXPIRYDATE Response $UOFFERresponseCode ! " ; log ' ' ; else log " $MSISDN  Offer $OFFERID with Expiry Date $EXPIRYDATE has been Added. " ; fi

else

DOFFERCountTMP=`cat $UCIP/DOFFER | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`
DOFFERCount=`expr $DOFFERCountTMP - 1`


cat << EOF > $tmpDir/DOFFER.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DOFFER | sed  's/\\"/\\\"/g' | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/OFFERID/'"$OFFERID"'/g' |  sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$DOFFERCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DOFFER.sh
$tmpDir/DOFFER.sh > $tmpDir/DOFFER.out

DOFFERresponseCode=`cat $tmpDir/DOFFER.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DOFFERresponseCode ]] ; then DOFFERresponseCode=-100 ; fi
if [ $DOFFERresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete Offer $OFFERID Response $DOFFERresponseCode ! " ; log ' ' ;  else log " $MSISDN  Offer $OFFERID has been Deleted. " ; fi

fi
log ' '
done
fi


###################################################################################################
##                                 Update Usage Counter                                          ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "UC" ] ; then
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
USAGECOUNTERID=`echo $i | awk -F, '{print $2}'`
USAGECOUNTERVALUENEW=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UUCCount=`cat $UCIP/UUC | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGECOUNTERID/'"$USAGECOUNTERID"'/g'  | sed 's/USAGECOUNTERVALUENEW/'"$USAGECOUNTERVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UUC.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UUC | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGECOUNTERID/'"$USAGECOUNTERID"'/g' | sed 's/USAGECOUNTERVALUENEW/'"$USAGECOUNTERVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UUCCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UUC.sh
$tmpDir/UUC.sh > $tmpDir/UUC.out

UUCresponseCode=`cat $tmpDir/UUC.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UUCresponseCode ]] ; then UUCresponseCode=-100 ; fi
if [ $UUCresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Usage Counter $USAGECOUNTERID Response $UUCresponseCode ! " ;  echo " " ; else log " $MSISDN  Usage Counter ID $USAGECOUNTERID has been set to $USAGECOUNTERVALUENEW. " ; fi

log ' '
done
fi

###################################################################################################
##                                    Update Usage Threshold                                     ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "UT" ] ; then    
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
USAGETHRESHOLDID=`echo $i | awk -F, '{print $2}'`
USAGETHRESHOLDVALUENEW=`echo $i | awk -F, '{print $3}'`
###################################################################################################

UUTCount=`cat $UCIP/UUT | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGETHRESHOLDID/'"$USAGETHRESHOLDID"'/g'  | sed 's/USAGETHRESHOLDVALUENEW/'"$USAGETHRESHOLDVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

cat << EOF > $tmpDir/UUT.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UUT | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/USAGETHRESHOLDID/'"$USAGETHRESHOLDID"'/g' | sed 's/USAGETHRESHOLDVALUENEW/'"$USAGETHRESHOLDVALUENEW"'/g'| sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UUTCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UUT.sh
$tmpDir/UUT.sh > $tmpDir/UUT.out

UUTresponseCode=`cat $tmpDir/UUT.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UUTresponseCode ]] ; then UUTresponseCode=-100 ; fi
if [ $UUTresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update Usage Threshold $USAGETHRESHOLDID Response $UUTresponseCode ! " ; log ' ' ; else log " $MSISDN  Usage Threshold ID $USAGETHRESHOLDID has been set to $USAGETHRESHOLDVALUENEW. " ; fi

done
fi

###################################################################################################
##                       Set Periodic Account Management                                         ##
###################################################################################################
if [ $ACTION == "SET" ]&&[ $TYPE == "PAM" ] ; then
###################################################################################################
for i in `cat $WLIST` ; do
MSISDN=`echo $i | awk -F, '{print $1}'`
PAMACTION=`echo $i | awk -F, '{print $2}'`
PAMSERVICEID=`echo $i | awk -F, '{print $3}'`
PAMCLASSID=`echo $i | awk -F, '{print $4}'`
SCHEDULEID=`echo $i | awk -F, '{print $5}'`
PAMSERVICEPRIORITY=`echo $i | awk -F, '{print $6}'`
###################################################################################################

if [ $PAMACTION = 'ADD' ] ; then

UPAMCountTMP=`cat $UCIP/UPAM | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

UPAMCount=`expr $UPAMCountTMP - 1 `

cat << EOF > $tmpDir/UPAM.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/UPAM | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$UPAMCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/UPAM.sh
$tmpDir/UPAM.sh > $tmpDir/UPAM.out

UPAMresponseCode=`cat $tmpDir/UPAM.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $UPAMresponseCode ]] ; then UPAMresponseCode=-100 ; fi
if [ $UPAMresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Update PAM $PAMSERVICEID Response $UPAMresponseCode ! " ; log ' ' ; else log " $MSISDN  PAM ID $PAMSERVICEID Class $PAMCLASSID Schedule $SCHEDULEID Priority $PAMSERVICEPRIORITY has been added. " ; fi


else

DPAMCountTMP=`cat $UCIP/DPAM | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/$/ /g' | tail +8 | wc -m`

DPAMCount=`expr $DPAMCountTMP - 1 `

cat << EOF > $tmpDir/DPAM.sh
#!/usr/bin/expect
set timeout 30

spawn telnet $AirIP 10010
    expect "'^]'."
    send "`cat $UCIP/DPAM | sed  's/\\"/\\\"/g'   | sed 's/MSISDN/'"$MSISDN"'/g' | sed 's/PAMSERVICEID/'"$PAMSERVICEID"'/g'  | sed 's/PAMCLASSID/'"$PAMCLASSID"'/g' | sed 's/SCHEDULEID/'"$SCHEDULEID"'/g'  | sed 's/PAMSERVICEPRIORITY/'"$PAMSERVICEPRIORITY"'/g' | sed 's/TRANSACTIONDATE/'"$TRANSACTIONDATE"'/g' | sed 's/COUNT/'"$DPAMCount"'/g'`\r"
    expect "</methodResponse>"
EOF
chmod 777 $tmpDir/DPAM.sh
$tmpDir/DPAM.sh > $tmpDir/DPAM.out

DPAMresponseCode=`cat $tmpDir/DPAM.out | nawk 'c-->0;$0~s{if(b)for(c=b+1;c>1;c--)print r[(NR-c+1)%b];print;c=a}b{r[NR%b]=$0}' b=0 a=1 s="responseCode" | grep value | sed 's/\(.*>\)\([0-9].*\)\(<.*><.*\)/\2/g' | sed 's/ //g'`
if [[ -z $DPAMresponseCode ]] ; then DPAMresponseCode=-100 ; fi
if [ $DPAMresponseCode -ne 0 ] ; then log " $MSISDN  Invalid Delete PAM $PAMSERVICEID Response $DPAMresponseCode ! " ;  echo " " ; else log " $MSISDN  PAM ID $PAMSERVICEID has been deleted. " ; fi

fi
done
fi
###################################################################################################

fi ## SKIP=YES HELP=NO

echo "\n End: `date` \n\n " >>$oDir/$LogFile

log ' ' 
#rm -fr $tmpDir 2>/dev/null
