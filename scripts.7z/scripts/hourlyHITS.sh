
#!/usr/bin/bash
#By: Haytham Ismail.


cd /weblogic12c/app/oracle/config/domains/mydomain/servers/
min=`date +%M`
log10=hourlyHITS.log
rm -f $log10
statFile=/CHARGING_INTERFACE/logs/statistics/Hits10min/hourlyHits_`date +%Y%m%d`.csv

for i in `ls -d ci*`; do ls -rt $i/logs/access.log* |tail -2|head -1|grep -v gz; done > .logfiles1


for i in `cat .logfiles1`; do  dd=`date +%Y%m%d_%H:%M`;pt=`echo $i|nawk -F\/ '{print $1}'`;nawk -F\/ '{print $5}' "$i"|nawk -F? '{print $1}'|sort |uniq -c |sort -nr|nawk '{print "'$pt'",$0}' |nawk '{print "'$dd'",$0}'|sed 's/ /,/g;s/,,,/,/g;s/,,/,/g'|nawk -F, '{print $1","$2","$4","$3}'>> $log10; done


echo "##########################" >> "$statFile"
cat "$log10" >> "$statFile"

if [ `date +%H` -eq 0 ];then

find /CHARGING_INTERFACE/logs/statistics/Hits10min/ -type f -name "hourlyHits*.csv" -mtime +60 -exec rm {} \;
l_file=`ls -rt /CHARGING_INTERFACE/logs/statistics/Hits10min/hourlyHits_*|tail -2|head -1`
l_file2=`ls -rt /CHARGING_INTERFACE/logs/LogStatusExtractor_*log|tail -2|head -1`
l_file3=`ls -rt /CHARGING_INTERFACE/logs/PortsExecutionTime_*.log|tail -2|head -1`
l_file4=`ls -rt /CHARGING_INTERFACE/logs/statistics/AirUCIPS_*.log|tail -2|head -1`
l_file5=`ls -rt /CHARGING_INTERFACE/logs/statistics/AirEcodes_*.log|tail -2|head -1`
echo "ftp yesterdays file to capacity system, file:"$l_file"."
scp "$l_file" "$l_file2" "$l_file3" "$l_file4" "$l_file5" vas_sys@172.21.38.231:/export/home/vas_sys/ChargingInterface/CImachine01/Hits10Min/
fi
