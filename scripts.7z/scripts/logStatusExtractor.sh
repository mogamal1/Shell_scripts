#!/usr/bin/bash
#Extract and consalidate STATUS error code per weblogic server log file
#By: Shreef Khattab.
#Copyright are reserved.
#vodafone Egypt. Jun. 2014.

wd=/CHARGING_INTERFACE/logs
cd "$wd"
logfile=LogStatusExtractor_`date +%Y%m%d`.log

if [ "$#" -eq 1 -a "$1" == 'logonly' ];then log_flag=1; else log_flag=0; fi

logme()
{
if [ "$log_flag" -eq 1 ];then
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* "|sed 's/\[//g;s/\]//g;s/ /,/g;s/\|/,/g;s/_/,/1;s/charging_trace_//g;s/.log,ThisHour,STATUS//g;s/.$//g'   >> "$wd"/"$logfile" ;
else
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* ";
fi
}


echo "## > log status in THIS HOUR: ## [`date +%Y%m%d_%H:xx:xx`]"  |while read line;do logme "$line";done

for i in `ls charging_trace_70??.log`;do grep `date +%Y%m%d_%H:` "$i"|egrep "STATUS,|STATUS=|STATUS>"|nawk -F\| '{print $4}'|nawk -F\; '{print $1}'|sed 's/-100&/-100,/'|nawk -F\& '{print $1}'|sed 's/\(_..\)\(.*\|\)/\1|/g;s/ //g;s/\[.*\]//g;s/InparseResponse(),inputstream\[//g;s/STATUS=/STATUS,/g;s/<?xmlversion="1.0"?><response><STATUS>/STATUS,/;s/<\/STATUS><\/response>//'|grep STATUS|sort|uniq -c|nawk '{printf ("'$i'|ThisHour|%s|%d\n" ,$2,$1)}';echo "";done  |while read line;do logme "$line";done



if [ "$log_flag" -eq 1 ];then
echo "Statistics is generated and logged to file."
else
echo
echo "###################################################"
echo "####### By: Shreef Khattab - Charging Team ########"
echo "###################################################"
fi
