#!/usr/bin/bash 
#Heart Beat for Charging Nodes Checker
#By: Shreef Khattab.

wd=/housekeeping/crontab/
cd $wd

:> mail.txt

### autoAdd part ###
for i in `ls *-*|grep -v Nemo-crontab.sh|grep -v txt`; do a=`grep -c ^"$i"$ hosts`; if [ "$a" -eq 0 ]; then echo "##Auto Added `date +%Y%m%d_%H:%M`" ;echo "$i"; fi;grep -wv "$i" .notfoud > .notfoud.n; mv .notfoud.n .notfoud; done >> hosts

for n in `grep -v "^#" hosts|sort -n|uniq`;do
if [ -e "$n" ];then
rm "$n"
else
echo "$n" >> .notfoud
echo "NewNemo2"                                                                          >cron.txt
echo "4"                                                                                 >>cron.txt
echo "Heart Beat Off"                                                                    >>cron.txt
echo "Node down OR crontab not running"                                                  >>cron.txt
echo "NA"                                                                                >>cron.txt
echo "1"                                                                                 >>cron.txt
echo "Node $n is unavailable. It could be down or lost connection or crond not running"  >>cron.txt
mv cron.txt "$n"_cron_`date +%d%m%Y`.txt

######### Generating Mail File #########
echo "Host: "$n""       >> mail.txt

cp "$n"_cron_`date +%d%m%Y`.txt /home/nemo/
mv "$n"_cron_`date +%d%m%Y`.txt /housekeeping/crontab/logs/"$n"_cron_`date +%d%m%Y_%H:%M`.txt
fi
done

if [ `cat mail.txt|wc -l` -gt 0 ];then
echo ' '  														 >>mail.txt
echo 'Node(s) is/are unavailable. Server could be down or lost network connection or cron daemon is not running.'        >>mail.txt
echo ' '														 >>mail.txt
echo 'Heartbeat nodes monitoring by: ' 											 >>mail.txt
echo 'Mohamed Gamal - Charging Services Team.'										 >>mail.txt
echo "" > .mail.t.t; cat mail.txt >> .mail.t.t; mv .mail.t.t mail.txt &> /dev/null
java_old -jar .itelnet.jar -c .Send_Mail.txt -p "Crontab_Nemo@vodafone.com,.to"
#rm mail.txt cron.txt
fi


if [ `date +%H` -eq 15 -o "$#" -ne 1 ];then
sort -n .notfoud|uniq -c|nawk '{if($1>25){print $2}}' > .ToBeRemoved
for i in `cat .ToBeRemoved`
do
grep -wv "$i" hosts > .hosts.n ; cp .hosts .hosts_b4_`date +%Y%m%d%H%M`;mv .hosts.n .hosts
grep -wv "$i" .notfoud > .notfoud.n; mv .notfoud.n .notfoud
done
fi

find /housekeeping/crontab/logs/ -type f -mtime +50 -exec rm {} \;
