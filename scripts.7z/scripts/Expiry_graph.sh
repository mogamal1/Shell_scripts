gawk -F, '{if($1!=1&&!$2&&$6~/'20'../){print $3","$4","$5","$6","$8}}' *_VSdump.csv |uniq >  Expired-ALL.csv
gawk -F, '{print $3","$4","$1","$2}' Expired-ALL.csv |sed 's/^\(....\)\(..\)\(..\),/\2-\1,/' > E2-ALL.csv
gawk -F, '{print $2","$1","$3","$4}' E2-ALL.csv |sed 's/^\(....\)\(..\)\(..\),/\2-\1,/' > E3-ALL.csv
cat E3-ALL.csv  |sort -n|uniq -c|gawk '{print $1","$2}' > E4-ALL.csv
