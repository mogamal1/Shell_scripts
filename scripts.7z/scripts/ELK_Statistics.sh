#!/usr/bin/bash

export SHELL=/bin/bash
export TERM=vt100


home=/export/home/fdsuser/SDP_REPORTS/ELK
wd=/export/home/fdsuser/SDP_REPORTS/ELK/working
running=/export/home/fdsuser/SDP_REPORTS/ELK/working/Running
SdpUser=upmuser
SdpPass=upmuser_123
Minute=`date  +%M`

mkdir -p $running 2>/dev/null
touch $running/ELKstatistics.running

#######################################

cd $wd

for i in `cat /export/home/fdsuser/SDP_REPORTS/SDP_LIST` ; do

SDP=`echo $i | awk -F'_' '{print $1}'`
IP=`echo $i | awk -F'_' '{print $2}'`

echo ""
echo "Getting $SDP Statistics"

#######  Getting SDP Statistics  #######

cd $wd
echo '#!/usr/bin/expect'                                                                                 >SdpStat.sh_"$SDP"
echo 'set timeout 30'                                                                                   >>SdpStat.sh_"$SDP"
echo "eval spawn sftp `echo -o StrictHostKeyChecking=no -o ConnectTimeout=5 $SdpUser@$IP`"              >>SdpStat.sh_"$SDP"
echo "expect \"word: \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"$SdpPass"'\\r'"\""                                                                        >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"cd /tmp"'\\r'"\""                                                                         >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"lcd $wd"'\\r'"\""                                                                         >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"mget G*SDP*"'\\r'"\""                                                                     >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"

chmod 777 $wd/SdpStat.sh_"$SDP"
nohup $wd/SdpStat.sh_"$SDP" & 2>/dev/null  && echo $!  >> PID
done


## Wait until all files are copied ##


GREP=`cat PID |  perl -pe 'if(!eof){chomp;$_.=" | "}'`
count=0
PIDsum=1

while [ "$PIDsum" -gt 0 ] && [ "$count" -lt 60 ]
do
PIDsum=`ps -ef | grep -v grep | egrep " $GREP " | wc -l |awk 'BEGIN {sum=0;OFMT="%.0f"}{sum=sum+$1} END{print sum}' `
count=`expr $count + 1 `
sleep 4
done

for i in `cat PID` ; do kill -9 $i 2>/dev/null ; done

########################################


:> $home/Gy_all
:> $home/Gx_all
:> $home/Gx_RAR

for i in `cat /export/home/fdsuser/SDP_REPORTS/SDP_LIST` ; do

SDP=`echo $i | awk -F'_' '{print $1}'`

cat $wd/Gy_all_"$SDP"  >> $home/Gy_all
cat $wd/Gx_all_"$SDP"  >> $home/Gx_all
cat $wd/Gx_RAR_"$SDP"  >> $home/Gx_RAR

done

cd $home
rm -fr $wd  2>/dev/null
########################################
