#!/usr/bin/bash
# BY mohamed Gamal 

export SHELL=/bin/bash
export TERM=vt100


home=/export/home/fdsuser/SDP_REPORTS/SPLUNK
wd=/export/home/fdsuser/SDP_REPORTS/SPLUNK/working
running=/export/home/fdsuser/SDP_REPORTS/SPLUNK/working/Running
SdpUser=upmuser
SdpPass=upmuser_123
Minute=`date  +%M`

mkdir -p $running 2>/dev/null
touch $running/SPLUNKstatistics.running

#######################################

cd $wd

for i in `cat /export/home/fdsuser/SDP_REPORTS/SDP_LIST` ; do

SDP=`echo $i | awk -F'_' '{print $1}'`
IP=`echo $i | awk -F'_' '{print $2}'`

echo ""
echo "Getting $SDP Statistics"

#######  Getting SDP Statistics  #######

cd $wd
echo '#!/usr/bin/expect'                                                                                 >SdpStat.sh_"$SDP"
echo 'set timeout 30'                                                                                   >>SdpStat.sh_"$SDP"
echo "eval spawn sftp `echo -o StrictHostKeyChecking=no -o ConnectTimeout=5 $SdpUser@$IP`"              >>SdpStat.sh_"$SDP"
echo "expect \"word: \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"$SdpPass"'\\r'"\""                                                                        >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"cd /tmp"'\\r'"\""                                                                         >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"lcd $wd"'\\r'"\""                                                                         >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"
echo "send  \"mget SPLUNK_G*SDP*"'\\r'"\""                                                              >>SdpStat.sh_"$SDP"
echo "expect \"sftp> \""                                                                                >>SdpStat.sh_"$SDP"

chmod 777 $wd/SdpStat.sh_"$SDP"
nohup $wd/SdpStat.sh_"$SDP" & 2>/dev/null  && echo $!  >> PID
done


## Wait until all files are copied ##


GREP=`cat PID |  perl -pe 'if(!eof){chomp;$_.=" | "}'`
count=0
PIDsum=1

while [ "$PIDsum" -gt 0 ] && [ "$count" -lt 60 ]
do
PIDsum=`ps -ef | grep -v grep | egrep " $GREP " | wc -l |awk 'BEGIN {sum=0;OFMT="%.0f"}{sum=sum+$1} END{print sum}' `
count=`expr $count + 1 `
sleep 4
done

for i in `cat PID` ; do kill -9 $i 2>/dev/null ; done

########################################


:> $home/SPLUNK_Gy_all
:> $home/SPLUNK_Gx_all
:> $home/SPLUNK_Gx_RAR

for i in `cat /export/home/fdsuser/SDP_REPORTS/SDP_LIST` ; do

SDP=`echo $i | awk -F'_' '{print $1}'`

cat $wd/SPLUNK_Gy_all_"$SDP"  >> $home/SPLUNK_Gy_all
cat $wd/SPLUNK_Gx_all_"$SDP"  >> $home/SPLUNK_Gx_all
cat $wd/SPLUNK_Gx_RAR_"$SDP"  >> $home/SPLUNK_Gx_RAR

done

cd $home
rm -fr $wd  2>/dev/null
########################################
######### SPLUNK MACHINE FTP ###########

scp /export/home/fdsuser/SDP_REPORTS/SPLUNK/SPLUNK_Gx_all  Charging_Domain@172.21.57.33:/home/ftp/charging/SDP/GX_all/

scp /export/home/fdsuser/SDP_REPORTS/SPLUNK/SPLUNK_Gx_RAR  Charging_Domain@172.21.57.33:/home/ftp/charging/SDP/GX_rar/

scp /export/home/fdsuser/SDP_REPORTS/SPLUNK/SPLUNK_Gy_all  Charging_Domain@172.21.57.33:/home/ftp/charging/SDP/GY_all/
