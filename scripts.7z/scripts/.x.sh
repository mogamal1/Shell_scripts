#!/bin/bash
#Total NGVS monthly report.
#By:Shreef Khattab.
#Enhanced By Mohamed Gamal
#VODAFONE EGYPT 2019 -- CHARGING TEAM  
#ALL RIGHTS RESERVED 
#=====================================
cd /var/opt/vs/main/reports/done

# date of closed month
report_month=`date -d "-12 day" +%Y%m`

# :=report_month - 1
report_lst_month=`date -d "-52 day" +%Y%m`
output_lst_d=${report_lst_month}_dump_output

# :=report_month + 1
report_nxt_month=`date +%Y%m`

formated_dump=`date +%Y%m`01_Total_VSdump.csv 
TTdump=`date +%m_12_%Y`

output_d=${report_month}_dump_output
#mkdir ${output_d} 2>/dev/null
#=====================================
send_sms()
{
for c in `grep -v ^# /housekeeping/NewNemo/script.d/.smsContacts|awk -F: '{print $2}'`
do
echo "$c;$2"            >> "$1".sms
done
/housekeeping/NewNemo/ftp/ftp_Nemo_New.sh . /housekeeping/SMS_sender/ "$1".sms
rm "$1".sms
return 0
}
#======================================
##--------------------------------
## Variance
echo "[`date +%Y%m%d" "%H:%M`]  Calculating  \"Variance\" "
LOADED=`grep -i TOTAL ${output_d}/${report_month}_loaded_grouped.csv|gawk -F, '{print $4}'`
OLD_AVAIL=`grep -i TOTAL ${output_lst_d}/${report_lst_month}_available_grouped.csv|gawk -F, '{print $4}'`
SUM=`echo $LOADED + $OLD_AVAIL | bc`
VAR=`grep -i TOTAL ${output_d}/${report_month}_*_grouped.csv|grep -iv loaded |gawk -v sm=${SUM} -F, 'BEGIN{S=sm}{V=$4;S-=V}END{printf("%.0f\n", S)}'`

echo "[`date +%Y%m%d" "%H:%M`] Variance for current month is $VAR"
send_sms NGVS "VS Report variance for `date +%b-%Y` closure is "$VAR" L.E. "
##--------------------------------
