
###w part is to check once every day for all the hashed nodes in 'hosts' file and send email notification to remind of hashed nodes ####

wd=/housekeeping/crontab/

H=`date +%H`
M=`date +%M`
#if [ $H -eq 12 -a M -eq 00 ]
#then
cd $wd
for x in `grep -i "^#" hosts | egrep -v "To |you |until|#$|By:"`;do
echo $x | cut -c 2- >> hashed_nodes.txt
done

if [ `cat hashed_nodes.txt | wc -l`  -gt 0 ]
then

for i in `cat hashed_nodes.txt` ;do

if [ -e $i ];then
echo $i >> online_nodes.txt

else 
echo $i >> offline_nodes.txt
fi

done
fi
#### create mail file 
echo 'the below nodes are hashed into hosts file and now they are online'   >>mail.txt
echo " "   							>>mail.txt
cat  online_nodes.txt                                           >>mail.txt

echo " "  							>>mail.txt
echo 'the below nodes are hashed into hosts file and still offline' >>mail.txt
echo " "   							>>mail.txt
cat offline_nodes.txt        >>mail.txt

echo "" > .mail.t.t; cat mail.txt >> .mail.t.t; mv .mail.t.t mail.txt &> /dev/null
java_old -jar .itelnet.jar -c .Send_Mail.txt -p "crontab-Nemo@vodafone.com,.to"
rm mail.txt online_nodes.txt offline_nodes.txt hashed_nodes.txt
#fi
