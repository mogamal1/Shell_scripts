#!/usr/bash

/usr/bin/curl -XDELETE http://10.21.95.132:9200/sdp-statistics-*-`date -d "-10 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/ciaccess*-`date -d "-6 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/cihitslog*-`date -d "-10 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/hitslog-titoadsldb-`date -d "-14 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/offline-titoadsldb-`date -d "-14 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/.monitoring-es-6-`date -d "-2 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/cistatistics-portsexecutiontime-`date -d "-14 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/ccat-service-classes-*`date -d "-3 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/cistatistics-airexecutiontime-`date -d "-4 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/cpu-utilization-`date -d "-60 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/ram-utilization-`date -d "-60 days" +"%Y.%m.%d"` -u house_keeper:house_keeper
/usr/bin/curl -XDELETE http://10.21.95.132:9200/ram-utilization-`date -d "-60 days" +"%Y.%m.%d"` -u house_keeper:house_keeper