#**********************************************************************************************
#             File : RestartServers.py
#        Author(s) : Mohamed Gamal (V18MBary)
#          Created : 2019-06-16
# 
# Copyright (c) 2019 Charging Services team Vodfone EG, Egypt. All rights reserved.
# The copyright to the computer program or programs herein is the 
# property of Vodafone EG, Egypt. The program or programs
# may be used and/or copied with the written permission
# from Vodafone EG or in accordance with the terms and conditions 
# stipulated in the agreement/contract under which the
# program has been supplied.
# *********************************************************************************************
#
# --PREQUISITES--  AdminServer needs to be up and running.
# Script compatible with WebLogic Server Version: 12.2.1.2.0 or above 
# It does not stop or start the AdminServer.
# It will restart managed servers simultaneously.
# It will print "Node Status is [OK]" when restart done successfully for all ports per machine
#                                                                                  ___________ 
# Versions
# RestartServers.py v1.0 2019/06/07  V18Mbary  
# RestartServers.py v1.1 2019/06/13  V17AAhmed22 
# RestartServers.py v1.2 2019/06/16  V18Mbary  
# RestartServers.py v1.3 2019/06/19  V18Mbary 
# RestartServers.py v1.4 2020/05/20  V18Mbary  -- Add New RMD CI site 
# RestartServers.py v1.5 2020/05/21  V18Mbary  -- Add connect timeout and log redirection 
# RestartServers.py v1.6 2020/05/21  V18Mbary  -- Rollback connect timeout 
#
# execfile('RestartServers.py')
import sys 

def stopAllManagedServers():

 domainRuntime();
 global ports
 tasks = []
 ports = [] 

 for server in cmo.getServerLifeCycleRuntimes():
     if (server.getName() != "AdminServer" and server.getState() != "SHUTDOWN" ):
         ports.append(server)
         tasks.append(server.shutdown())
                         
 return tasks
#=======================================================================
def startAllManagedServers():
     
 tasks = []
     
 for server in ports:
     if (server.getName() != "AdminServer" and server.getState() != "RUNNING" ):
        tasks.append(server.start()) 

 return tasks
#========================================================================
def waitTillCompleted (tasks):
     
 while (len(tasks) > 0):
   for task in tasks:
       if task.getStatus() != "TASK IN PROGRESS" :
          tasks.remove(task)

 java.lang.Thread.sleep(5000)
#======================================================================== 
def checkServerStatus ():

 counter=0
 for server in cmo.getServerLifeCycleRuntimes():
     if (server.getName() != "AdminServer" and server.getState() == "RUNNING" ):
        counter += 1

 if (len(ports) == counter):
    print "",Url, "Node status is [OK]."
 else:
    print "",Url, "Node status is [UNKNOWN] ... "
#================================  CODE  =================================
#storeUserConfig('conf.secure','key.secure')
redirect('./wlst.log','false')
Urls = ['172.28.201.72','172.23.99.6','10.21.126.73','10.21.126.74','10.21.127.194','10.21.127.195','10.28.180.22']
for Url in Urls: 
    connect(userConfigFile='conf.secure',userKeyFile='key.secure',url=Url+':7001')
    print "",Url, "Node Connected"
    tasks = []
    ports = []
    tasks = stopAllManagedServers()
    waitTillCompleted (tasks)
    tasks = startAllManagedServers()
    waitTillCompleted (tasks)
    checkServerStatus ()
    disconnect()
    java.lang.Thread.sleep(5000)

sys.exit()