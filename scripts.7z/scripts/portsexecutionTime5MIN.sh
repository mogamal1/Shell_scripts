#!/usr/bin/bash
#Extract and consalidate STATUS error code per weblogic server log file
#By: Shreef Khattab.
#Copyright are reserved.
#vodafone Egypt. Jun. 2014.
#Modified by: Haytham Ismail 04/2017

wd=/CHARGING_INTERFACE/logs
cd "$wd"
dt_H=`/usr/bin/date +%Y%m%d_%H`
TSTMP=`/usr/bin/date +%Y%m%d_%H%M`
touch /CHARGING_INTERFACE/logs/portslastHits/.ref
logfile=PortsExecutionTime_`date +%Y%m%d`.5MIN.log
last5min=`tail -7 .GenerateIntervals.log|head -5|nawk 'BEGIN{printf "\""}{printf "^"$1":|"}END{printf "\b\"\n"}'`
logdir15=statistics/ExecutionTime15min
logfile15=ExecutionTime_`date +%Y%m%d`.15MIN.log
tl=2000000

if [ "$#" -eq 1 -a "$1" == 'logonly' ];then log_flag=1; else log_flag=0; fi

ddd=`/usr/bin/date '+%Y%m%d,%H:%M'`
logme()
{
if [ "$log_flag" -eq 1 ];then
echo "`hostname`,"$ddd",$*," >> "$wd"/"$logfile" ;
else
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* ";
fi
}

logme15()
{
if [ "$log_flag" -eq 1 ];then
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* " >> "$logdir15"/"$logfile15" ;
else
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* ";
fi
}

if [ `date +%M` -ge 4 ];then
echo "`date +%Y%m%d`" > "$wd"/.day; echo "`date +%H`" > "$wd"/.hour; for trc_log in `ls "$wd"/charging_trace_70??.log`;do pt=`echo "$trc_log"|nawk -F\. '{print $1}'|nawk -F_ '{print $4}'`;if [ "$log_flag" -ne 1 ];then printf ".";fi; tail -"$tl" "$trc_log"|egrep "$last5min" >> "$wd"/portslastHits/log5min_"$pt"_"$TSTMP"; done;echo ""
else
day=`cat "$wd"/.day`;hour=`cat "$wd"/.hour`;for trc_log in `ls -rt "$wd"/charging_trace_70??.log."$day"."$hour"`;do pt=`echo "$trc_log"|nawk -F\. '{print $1}'|nawk -F_ '{print $4}'`; if [ "$log_flag" -ne 1 ];then printf ".";fi; tail -"$tl" "$trc_log"|egrep "$last5min" >> "$wd"/portslastHits/log5min_"$pt"_"$TSTMP"; done
fi

echo "## > log status in last (5 min) till: ## [`date +%Y%m%d_%H=%M:xx`]"  |while read line;do logme "$line";done
echo "Machine,date,time,Port,TotalRequets,MaxTime,MinTime,GreaterThan2Sec,GraterThan5Sec,AvgTime" >> "$wd"/"$logfile"
##echo "## > log status in last (15 min) till: ## [`date +%Y%m%d_%H=%M:xx`]" |while read line;do logme15 "$line";done

for file in `ls "$wd"/portslastHits/log5min_70*_"$TSTMP"`;do pt=`echo "$file"|nawk -F_ '{print $3}'`
ln -sf "$wd"/portslastHits/log5min_"$pt"_"$TSTMP" .trc_logf5_"$pt"


grep "Request Finished with" .trc_logf5_"$pt"|sed 's/\- \[.* (//g;s/-*-//g'|nawk 'BEGIN{st=0;sf=0;t=0;mx1=0;mx2=0;mx3=0;mx4=0;mx5=0;mn=50}{t+=$2;st+=($2>2000&&$2<5000?1:0);sf+=($2>5000?1:0);if($2>=mx1){mx5=mx4;ln5=ln4;mx4=mx3;ln4=ln3;mx3=mx2;ln3=ln2;mx2=mx1;ln2=ln1;mx1=$2;ln1=$0;}else{if($2>=mx2){mx5=mx4;ln5=ln4;mx4=mx3;ln4=ln3;mx3=mx2;ln3=ln2;mx2=$2;ln2=$0}else{if($2>=mx3){mx5=mx4;ln5=ln4;mx4=mx3;ln4=ln3;mx3=$2;ln3=$0}else{if($2>=mx4){mx5=mx4;ln5=ln4;mx4=$2;ln4=$0}else{if($2>=mx5){mx5=$2;ln5=$0}}}}};mn=($2<mn?$2:mn)}END{printf ('$pt'",%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,(%s,(%s,(%s,(%s,(%s\n",NR,mx1,mn,st,sf,t/NR,ln1,ln2,ln3,ln4,ln5)}'|sed 's/|........_..:..:..:...|INFO.../|/g;s/] /|/g;s/ msec../)/g;s/\|INFO\|\|\[//g;s/........_..:..:..:...//g'|while read line;do logme "$line";done
dd=`date +%Y%m%d,%H:%M`
grep 'Result of' .trc_logf5_"$pt"|grep -v Component|awk '{print $3}' |sort |uniq -c|sort -nr|awk '{print '$pt'","$2","$1}'|awk '{print "'$dd'"","$0}'|sed 's/ /,/g' >> /CHARGING_INTERFACE/logs/statistics/AirUCIPS_`date +%Y%m%d`.log
grep 'Result of' .trc_logf5_"$pt"|grep -v Component|sed 's/.*ecode\[//g;s/].*//g'|sort |uniq -c|sort -nr|awk '{print '$pt'","$2","$1}'|awk '{print "'$dd'"","$0}'|sed 's/ /,/g' >> /CHARGING_INTERFACE/logs/statistics/AirEcodes_`date +%Y%m%d`.log


##grep -v "##" "$wd"/"$logfile"|tail -3|sed 's/ /,/g;s/:/,/g' >  "$wd"/.15min
##nawk -F, 'BEGIN{t=0;m=0;mn=0;g2=0;g5=0;a=0}{t+=$5;m=(m<$7?$7:m);mn=(mn<$9?mn:$9);g2+=$11;g5+=$13;a+=$15}END{printf("TotalRequets=%.0f,MaxTime=%.0f,MinTime=%.0f,GreaterThan2Sec=%.0f,GraterThan5Sec=%.0f,AvgTime=%.0f\n",t,m,mn,g2,g5,a/NR)}' "$wd"/.15min|while read line;do logme15 "$line";done

done
#####[ `date +%H` -eq 0  ] && touch /CHARGING_INTERFACE/logs/portslastHits/.ref

if [ "$log_flag" -eq 1 ];then
###ls "$wd"/portslastHits/|tail -30 >"$wd"/portslastHits/.last
###excld=`cat "$wd"/portslastHits/.last`
###rm `ls "$wd"/portslastHits/log5min_*|egrep -v "$excld"` 2>/dev/null
find /CHARGING_INTERFACE/logs/portslastHits/ -name 'log5min_*' ! -newer /CHARGING_INTERFACE/logs/portslastHits/.ref -exec rm {} \;
find /CHARGING_INTERFACE/logs -name 'PortsExecutionTime_*' -mtime +15 -exec rm {} \;
echo "Statistics are generated and logged to file."
###else
echo
echo "###################################################"
echo "####### By: Haytham Ismail & Shreef Khattab - Charging Team ########"
echo "###################################################"
fi
