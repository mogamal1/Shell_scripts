 grep $1  `find  /weblogic12c/app/oracle/config/domains/mydomain/servers/ci*/logs/*  -name "*log*" -mtime -1 `
grep -i msec   charging_trace_70*.log |sed "s/\[/ /g" |sed "s/\]//g"  |sed "s/msec/ msec/g" |sed "s/) -------//g" |sed "s/in[0-9]/in /g"  |awk  '($(NF-1)>=10000) {print $0 }' |more
