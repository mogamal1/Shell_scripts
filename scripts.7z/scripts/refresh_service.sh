#!/bin/bash
#By: Haytham Ismail.
#script to refresh Service on all online Ports


if [ `id|egrep -ic "oracle|devops"` -eq 0 ];then
echo "Only oracle user can run this Script
Exiting .........."
exit -103
fi

cd /mydomain/script

up=`netstat -an|grep LISTEN|grep 10.22.22.9.70|egrep -v "7001|7035"|awk '{print $1}'|awk -F. '{print $5}'|sort`

if [ "$#" -ne 1 ];then
        echo "Invalid i/p parameters"
        echo "$0 Service_name"
		echo "Example: $0 Mared_Trio_Recharge"
        exit -3
fi

Service=$1
 echo "####`date`####"
for i in `echo $up`
do

   wget "http://10.22.22.9:"$i"/PES/RefreshService?serviceId="$Service"" -o .refresh_service.log
      res=`cat RefreshService\?serviceId\="$Service"|grep -ci successfully`
	  if [ $res -eq 1 ];then
	  echo ""$i" Refresh Done."
	  else
	  echo ""$i" Refresh Failed."
	  fi
	  rm RefreshService\?serviceId\="$Service"
done

echo "### Haytham Ismail ###"