#!/usr/bin/bash
#By: Shreef Khattab.

cd /housekeeping/crontab/
grep -v ^# hosts |nawk '{print "ls -lh " $1}'|sh 1>/dev/null
