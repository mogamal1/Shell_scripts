#!/usr/bin/bash
#Customer hits extraction tool.
#By: Shreef Khattab.

day=`date +%b' '%d|sed 's/ 0/  /'`
msisdn=`echo "$1"|sed 's/^201/1/;s/^01/1/'`

if [ "$#" -lt 1 -o `echo "$msisdn"|nawk '{if(length($1)!=10){print "1"}else{print "0"}}'` -eq 1 -o "$#" -gt 2 ];then
echo "Invalid i/p parameter!"
echo "USAGE: "$0" MSISDN_10xxx"
echo "USGAE: "$0" MSISDN_10xxx \"Feb 18\""
echo "USGAE: "$0" MSISDN_10xxx \"Jan  8\""
exit -13
fi

if [ "$#" -eq 2 ];then
day=`echo "$2"|sed 's/\([A-z]\)\( [1-9]\)$/\1 \2/'`
fi

echo 
ls -l /weblogic12c/app/oracle/config/domains/mydomain/servers/ci*/logs/access.log*|grep -wv "ciQuota.."|grep "$day" 1>/tmp/.CH_"$$" 2>/dev/null

grep gz$  /tmp/.CH_"$$"|nawk 'BEGIN{logs=sheksa}{logs=logs" "$9}END{print "gzgrep 20'$msisdn' "logs}'|sh 1>/tmp/.CH_"$$".out  2>/dev/null
grep -v gz$ /tmp/.CH_"$$"|nawk 'BEGIN{logs=sheksa}{logs=logs" "$9}END{print "grep 20'$msisdn' "logs}'|sh 1>>/tmp/.CH_"$$".out 2>/dev/null


sed 's/\:/ /g;s/^.*servers//;s/\(.*\)\(ci.*\)\(.logs.access.log\)\([0-9]*\)/\2/' /tmp/.CH_"$$".out|gawk '{print $5" "$6":"$7":"$8"],["$11"],http("$13"),("$1"),("$2")"}'|sort -n

rm /tmp/.CH_$$* 2>/dev/null

echo
echo "################################"
echo "##CI Hits By: Shreef Khattab. ##"
echo "################################"
