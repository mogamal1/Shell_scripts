#!/bin/bash
#By: Haytham Ismail and Shreef



if [ `id|egrep -ic "oracle|devops"` -eq 0 ];then
echo "Only oracle user can run this Script
Exiting .........."
exit -103
fi

jar=/weblogic12c/app/oracle/product/ofm12.1.2/wlserver/server/lib/weblogic.jar

get_port()
{
read -p "Please enter Port Format:70XX (Ex: 7014): " portno

if [ `grep -c ^"$portno" ports` -eq 0 ];then
echo "invalid input...."
exit -104
fi
return "$portno"
}

check_restart()
{
portno="$1"
portnm="$2"
c=12
while true
do
((c--))
sleep 55
is_prt_up=`netstat -na|nawk '{print $1","$7}'|grep "\.70"|grep LISTEN|sed 's/\(.*\)\(....\)\(,L.*\)$/\2/'|sort -n|uniq|grep -wc "$portno"`
if [ "$is_prt_up" -eq 1 ];then
echo "Restart "$portnm","$portno" is done successfully."
break
elif [ "$c" -eq 1  ];then
echo "Failed to start weblogic server "$portnm":"$portno". Exiting script, please administrator to check .."
up=`netstat -an |grep 70 |grep -v 7001|grep LISTEN|cut -c 19-22|sort`
up_sms=`echo $up |sed 's/ 70/,/g'`
send_sms `hostname` "CI Failed while restarting "$portno",Up Ports="$up_sms""
exit -315
else
echo "Weblogic server "$portnm":"$portno" is still DOWN. Please, keep waiting .."
continue
fi
done
return 0
}

restart_port()
{
cd /mydomain/script/
portno=`echo "$1"`
portnm=`grep ^"$portno" ports|awk '{print $2}'`
[ -z "$portnm" ] && exit  -333

if [ `grep -cw "$portno" .netstat_$$` -lt 1 ];then
  echo "Port:$portno is already down."
  echo "skipping shutdown for weblogic server "$portno","$portnm" ..."
else
/mydomain/bin/setDomainEnv.sh
/mydomain/bin/setStartupEnv.sh
cd /mydomain/script/
  echo "## Shutting down weblogic server "$portnm":"$portno". ##"
 /mydomain/bin/stopManagedWebLogic.sh "$portnm" &>/dev/null &
  sleep 12
  echo "## Starting up weblogic server "$portnm":"$portno". ##"
 nohup /mydomain/bin/startManagedWebLogic.sh "$portnm"  1>/dev/null &
  check_restart "$portno" "$portnm"
fi

return 0
}

cd /mydomain/script/
rm .wblogic.out_* .netstat_* &>/dev/null
netstat -na|nawk '{print $1","$7}'|grep "\.70"|grep LISTEN|sed 's/\(.*\)\(....\)\(,L.*\)$/\2/'|sort -n|uniq|grep -v 7001 > .netstat_$$


if [ "$#" -eq 0 ]
then 
cat ports;
echo "-------"
read -p "Are you sure you want to restart all ports? (yes/no)" restart_all

if [ `echo $restart_all|grep -ic yes` -eq 1 ]
then
for i in `cat ports|awk '{print $1}'`
 do 
 portno="$i"
 restart_port "$portno"
done

elif [ `echo $restart_all|grep -ic no` -eq 1 ];then

get_port
echo "Restarting weblogic server port: "$portno" .."
restart_port "$portno"
fi

elif [ -s "$1"  ];then
 for i in `grep -v ^# "$1"`
  do
  portno=`echo "$i"`
  restart_port "$portno"
 done

elif [ "$#" -gt 0 ] && [ `grep -wc "$1" ports` -ge 1 ];then

 for i in $@
  do
  portno="$i"
  restart_port "$portno"
 done




elif [ "$#" -eq 1 ] && [ -n $1 ];then 


 if [ `echo "$1"|egrep -ci "all|app1|app2|quota"` -ne 1 ];then
  echo "invalid input "
  echo "Usage:"$0" All/app1/App2/quota"
  exit -199



 elif [ `echo "$1"|grep -iwc app1` -eq 1  ] ; then
  for i in `grep "700" .netstat_$$|awk '{print $1}'`
   do
   portno=`echo "$i"|awk '{print $1}'`
   restart_port "$portno"
  done
 
 elif [ `echo "$1"|grep -iwc app2` -eq 1  ] ; then
  for i in `grep "701" .netstat_$$|awk '{print $1}'`
   do
   portno=`echo "$i"|awk '{print $1}'`
   restart_port "$portno"
  done

 elif [ `echo "$1"|grep -ic quota` -eq 1  ] ; then
  for i in `grep "705" .netstat_$$|awk '{print $1}'`
   do
   portno=`echo "$i"|awk '{print $1}'`
   restart_port "$portno"
  done

 elif [ `echo "$1"|grep -ic all` -eq 1  ] ; then
  for i in `cat ports|awk '{print $1}'`
   do
   portno="$i"
   restart_port "$portno"
  done
 

 fi




fi
up=`netstat -an |grep 70 |grep -v 7001|grep LISTEN|cut -c 19-22|sort`
up_sms=`echo $up |sed 's/ 70/,/g'`
send_sms `hostname` "CIPorts Restart Done,Up Ports="$up_sms""

rm .wblogic.out_* .netstat_* &>/dev/null

echo " ####### Haytham Ismail #######"