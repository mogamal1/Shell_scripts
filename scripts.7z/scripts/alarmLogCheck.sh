#!/usr/bin/bash
#Extract and consalidate STATUS error code per weblogic server log file
#By: Shreef Khattab.

wd=/CHARGING_INTERFACE/logs/
cd "$wd"
logFile="$wd"/statistics/AppLog_`/usr/bin/date '+%Y%m%d'`.csv
tmplog=/tmp/.tmp.log
:> "$tmplog"
th_S=60
th_F=430

if [ "$#" -eq 1 -a "$1" == 'logonly' ];then log_flag=1; else log_flag=0; fi

logme()
{
if [ "$log_flag" -eq 1 ];then
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* " >> "$logFile" ;
else
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* ";
fi
echo "[`hostname` `/usr/bin/date '+%Y%m%d_%H:%M'`] $* " >> "$tmplog" ;
}

for i in `ls charging_trace_70??.log`;do egrep "STATUS,|STATUS=|STATUS>" "$i"|nawk -F\| '{print $4}'|nawk -F\; '{print $1}'|sed 's/-100&/-100,/'|nawk -F\& '{print $1}'|sed 's/\(_..\)\(.*\|\)/\1|/g;s/ //g;s/\[.*\]//g'|sort|uniq -c|nawk '{printf ("'`date +%Y%m%d_%H:`'|'$i'|%s|%d\n" ,$2,$1)}';done|sed 's/STATUS,/STATUS|/;s/STATUS=/STATUS|/;s/InparseResponse(),inputstream\[//g;s/<?xmlversion="1.0"?><response><STATUS>/STATUS|/;s/<\/STATUS><\/response>//'  > .result

##SuccessStatistics
egrep "TUS\|2\||TUS\|1\||TUS\|-1003\||TUS\|-1006\|" .result|nawk -F\| '{if(f==$2){s+=$5}else{if(NR!=1){print f":"s};t+=s;f=$2;s=$5}}END{if(s>0){print f":"s};t+=s;print "Success_Overall:"t}'|sed 's/\(charging_trace_\)\([0-9].*\)\(\.log\)/Success_\2/'  > .stat.succ

##FailedStatistics
egrep "TUS\|-100\||TUS\|-100,.*\||TUS\|-103\||TUS\|-6002\|" .result|egrep -v "TUS\|-100,B139\||TUS\|-100,B102\|"|nawk -F\| '{if(f==$2){s+=$5}else{if(NR!=1){print f":"s};t+=s;f=$2;s=$5}}END{if(s>0){print f":"s};t+=s;print "Failed_Overall:"t}'|sed 's/\(charging_trace_\)\([0-9].*\)\(\.log\)/Failed_\2/'   > .stat.fail

##FailedStatisticsSpecial=103
grep "TUS\|-103\|" .result|nawk -F\| '{if(f==$2){s+=$5}else{if(NR!=1){print f":"s};t+=s;f=$2;s=$5}}END{if(s>0){print f":"s};t+=s;print "Failed103_Total:"t}'|sed 's/\(charging_trace_\)\([0-9].*\)\(\.log\)/Failed103_\2/' > .stat.fail103



echo "####### Success per server check ,MIN threshold="$th_S" #######" |while read line;do logme "$line";done
cat .stat.succ	|while read line;do logme "$line";done
grep "Success_70..:" .stat.succ|nawk -F: 'BEGIN{l=0}{if($2<'$th_S'){l++;printf $1","}}END{if(l>0){printf "\n"}else{print "success) check is OK."}}'|sed 's/Success_//g;s/,$/) less than success threshold./;s/^./WebLogic(&/'	|while read line;do logme "$line";done


echo "####### Fail per server check ,MAX threshold="$th_F" #######"   |while read line;do logme "$line";done
cat .stat.fail	|while read line;do logme "$line";done
grep "Failed_70..:" .stat.fail|nawk -F: 'BEGIN{l=0}{if($2>'$th_F'){l++;printf $1","}}END{if(l>0){printf "\n"}else{print "fail) check is OK."}}'|sed 's/Failed_//g;s/,$/) greater than fail threshold./;s/^./WebLogic(&/'	|while read line;do logme "$line";done

cat .stat.fail103 |while read line;do logme "$line";done



if [ "$log_flag" -eq 1 ];then
echo "Statistics is generated and logged to file."
else
echo
echo "###################################################"
echo "####### By: Shreef Khattab - Charging Team ########"
echo "###################################################"
fi
